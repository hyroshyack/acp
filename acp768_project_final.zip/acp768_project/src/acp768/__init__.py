# src/acp768/__init__.py
"""Module principal pour l_application ACP768."""

__version__ = "1.0.0-refactored"

# Rendre certains composants clés accessibles plus facilement si nécessaire
# from .core.config_loader import ConfigLoader
# from .core.event_bus import EventBus
# from .core.logging_setup import setup_logging
# from .data_management.data_manager import DataManager
# from .blockchain_integration.api_handler import APIHandler
# from .trading_engine.arbitrage_manager import ArbitrageManager
# from .user_interface.ui_manager import UIManager

logger = logging.getLogger(__name__)

logger.info(f"ACP768 Application module initialized (version {__version__}).")

