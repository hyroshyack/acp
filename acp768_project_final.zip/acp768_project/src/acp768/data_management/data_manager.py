# src/acp768/data_management/data_manager.py
import asyncio
import logging
from typing import Any, List, Dict, Optional, Type

from acp768.core.config_loader import ConfigLoader
from acp768.core.event_bus import EventBus
# Importer les connecteurs spécifiques au besoin
from .connectors.base_connector import BaseDBConnector
from .connectors.sqlite_connector import SQLiteConnector
# from .connectors.redis_connector import RedisConnector # Exemple si Redis est implémenté
# from .connectors.mongo_connector import MongoConnector # Exemple si MongoDB est implémenté

# Placeholder pour les services de chiffrement et de nettoyage qui seront développés ultérieurement
# from acp768.security.encryption_service import EncryptionService
# from .data_cleaning_service import DataCleaningService

logger = logging.getLogger("acp768.data_management.data_manager")

class DataManager:
    """Orchestre la gestion des données, y compris le stockage, la récupération, le chiffrement et le nettoyage."""

    def __init__(self, config_loader: ConfigLoader, event_bus: Optional[EventBus] = None):
        self.config_loader = config_loader
        self.event_bus = event_bus
        self._connectors: Dict[str, BaseDBConnector] = {}
        self._default_connector_alias: Optional[str] = None
        # self.encryption_service = EncryptionService(config_loader) # À activer quand implémenté
        # self.cleaning_service = DataCleaningService() # À activer quand implémenté

        self._initialize_configured_connectors()

    def _initialize_configured_connectors(self) -> None:
        """Initialise les connecteurs de base de données basés sur la configuration."""
        db_configs = self.config_loader.get_section("Databases")
        if not db_configs:
            logger.warning("Aucune configuration de base de données trouvée dans la section [Databases].")
            return

        for alias, db_type in db_configs.items():
            if alias.endswith("_enabled") or alias.endswith("_default"): # Ignorer les clés de contrôle
                continue

            is_enabled = self.config_loader.get_boolean("Databases", f"{alias}_enabled", fallback=False)
            if not is_enabled:
                logger.info(f"Le connecteur de base de données ások{alias}" de type ások{db_type}" est désactivé.")
                continue

            connector_config_section = f"DB_{alias.upper()}"
            specific_config = self.config_loader.get_section(connector_config_section)
            if not specific_config:
                logger.error(f"Configuration manquante pour le connecteur ások{alias}" dans la section [{connector_config_section}].")
                continue
            
            connector_instance: Optional[BaseDBConnector] = None
            if db_type.lower() == "sqlite":
                connector_instance = SQLiteConnector(specific_config)
            # elif db_type.lower() == "redis":
            #     connector_instance = RedisConnector(specific_config)
            # elif db_type.lower() == "mongodb":
            #     connector_instance = MongoConnector(specific_config)
            else:
                logger.warning(f"Type de connecteur de base de données non supporté : {db_type} pour l'alias {alias}")
                continue
            
            if connector_instance:
                self._connectors[alias] = connector_instance
                logger.info(f"Connecteur de base de données ások{alias}" ({db_type}) initialisé.")
                if self.config_loader.get_boolean("Databases", f"{alias}_default", fallback=False):
                    if self._default_connector_alias:
                        logger.warning(f"Plusieurs connecteurs par défaut définis. Utilisation de ások{self._default_connector_alias}" au lieu de ások{alias}".")
                    else:
                        self._default_connector_alias = alias
                        logger.info(f"Connecteur ások{alias}" défini comme connecteur par défaut.")
        
        if not self._default_connector_alias and self._connectors:
            self._default_connector_alias = list(self._connectors.keys())[0]
            logger.info(f"Aucun connecteur par défaut explicitement défini. Utilisation de ások{self._default_connector_alias}" par défaut.")

    async def connect_all(self) -> None:
        """Connecte tous les connecteurs initialisés."""
        for alias, connector in self._connectors.items():
            try:
                await connector.connect()
            except Exception as e:
                logger.error(f"Échec de la connexion pour le connecteur ások{alias}": {e}", exc_info=True)

    async def disconnect_all(self) -> None:
        """Déconnecte tous les connecteurs actifs."""
        for alias, connector in self._connectors.items():
            try:
                await connector.disconnect()
            except Exception as e:
                logger.error(f"Échec de la déconnexion pour le connecteur ások{alias}": {e}", exc_info=True)

    def get_connector(self, alias: Optional[str] = None) -> BaseDBConnector:
        """Récupère un connecteur par son alias, ou le connecteur par défaut si alias est None."""
        target_alias = alias or self._default_connector_alias
        if not target_alias:
            raise ValueError("Aucun alias de connecteur spécifié et aucun connecteur par défaut n'est configuré.")
        
        connector = self._connectors.get(target_alias)
        if not connector:
            raise ValueError(f"Connecteur avec l'alias ások{target_alias}" non trouvé ou non initialisé.")
        return connector

    async def store_data(
        self, 
        collection_name: str, 
        data: Dict[str, Any], 
        unique_identifier_fields: Optional[List[str]] = None, # Pour SQLite, utilisé pour ON CONFLICT
        connector_alias: Optional[str] = None,
        encrypt: bool = False # Paramètre pour activer le chiffrement
    ) -> bool:
        """Stocke des données en utilisant le connecteur spécifié (ou par défaut)."""
        connector = self.get_connector(connector_alias)
        
        # data_to_store = data.copy()
        # if encrypt and hasattr(self, 'encryption_service')):
        #     try:
        #         data_to_store = await self.encryption_service.encrypt_dict_fields(data_to_store)
        #         logger.debug(f"Données chiffrées pour stockage dans {collection_name}.")
        #     except Exception as e:
        #         logger.error(f"Erreur lors du chiffrement des données pour {collection_name}: {e}", exc_info=True)
        #         return False
        
        # Pour SQLiteConnector, unique_identifier_fields est passé directement
        if isinstance(connector, SQLiteConnector):
            success = await connector.store_data(collection_name, data, unique_identifier_fields=unique_identifier_fields)
        else:
            # Pour d'autres connecteurs, unique_identifier peut être utilisé différemment (ex: pour un filtre d'upsert)
            unique_identifier_dict = {k: data[k] for k in unique_identifier_fields if k in data} if unique_identifier_fields else None
            success = await connector.store_data(collection_name, data, unique_identifier=unique_identifier_dict)

        if success and self.event_bus:
            await self.event_bus.publish_async("DATA_STORED", collection=collection_name, data_id=data.get("id")) # ou autre identifiant
        return success

    async def retrieve_data(
        self, 
        collection_name: str, 
        filters: Optional[Dict[str, Any]] = None,
        sort_by: Optional[List[tuple[str, int]]] = None,
        limit: Optional[int] = None,
        projection: Optional[List[str]] = None, # Pour SQLite, liste de noms de colonnes
        connector_alias: Optional[str] = None,
        decrypt: bool = False # Paramètre pour activer le déchiffrement
    ) -> List[Dict[str, Any]]:
        """Récupère des données en utilisant le connecteur spécifié (ou par défaut)."""
        connector = self.get_connector(connector_alias)
        
        # Pour SQLiteConnector, la projection est une liste de strings
        if isinstance(connector, SQLiteConnector):
            retrieved_rows = await connector.retrieve_data(collection_name, filters, sort_by, limit, projection=projection)
        else:
            # Pour d'autres connecteurs, la projection peut être un dict (ex: MongoDB {field: 1})
            # Adapter ici si nécessaire ou standardiser la signature de BaseDBConnector
            projection_dict = {field: 1 for field in projection} if projection else None
            retrieved_rows = await connector.retrieve_data(collection_name, filters, sort_by, limit, projection=projection_dict)

        # if decrypt and hasattr(self, 'encryption_service')):
        #     decrypted_results = []
        #     for row in retrieved_rows:
        #         try:
        #             decrypted_rows.append(await self.encryption_service.decrypt_dict_fields(row.copy()))
        #         except Exception as e:
        #             logger.error(f"Erreur lors du déchiffrement des données de {collection_name}: {e}", exc_info=True)
        #             decrypted_results.append(row) # Retourner la ligne non déchiffrée en cas d'erreur
        #     return decrypted_results
        return retrieved_rows

    async def update_data(
        self, 
        collection_name: str, 
        filters: Dict[str, Any], 
        update_fields: Dict[str, Any],
        upsert: bool = False, # Ce paramètre est plus pour les DB NoSQL comme MongoDB
        connector_alias: Optional[str] = None
    ) -> int:
        """Met à jour des données."""
        connector = self.get_connector(connector_alias)
        # data_to_update = update_fields.copy()
        # Potentiellement chiffrer les champs dans data_to_update si nécessaire
        modified_count = await connector.update_data(collection_name, filters, update_fields, upsert=upsert)
        if modified_count > 0 and self.event_bus:
            await self.event_bus.publish_async("DATA_UPDATED", collection=collection_name, filters=filters, num_updated=modified_count)
        return modified_count

    async def delete_data(self, collection_name: str, filters: Dict[str, Any], connector_alias: Optional[str] = None) -> int:
        """Supprime des données."""
        connector = self.get_connector(connector_alias)
        deleted_count = await connector.delete_data(collection_name, filters)
        if deleted_count > 0 and self.event_bus:
            await self.event_bus.publish_async("DATA_DELETED", collection=collection_name, filters=filters, num_deleted=deleted_count)
        return deleted_count

    # --- Méthodes pour la gestion des schémas (spécifiques à certains connecteurs) ---
    async def ensure_collection_or_table(self, collection_name: str, schema_definition: Optional[Any] = None, connector_alias: Optional[str] = None) -> None:
        """S'assure qu'une collection/table existe. Pour SQLite, schema_definition est la définition des colonnes."""
        connector = self.get_connector(connector_alias)
        if isinstance(connector, SQLiteConnector) and isinstance(schema_definition, str):
            await connector.ensure_table(collection_name, schema_definition)
        # Ajouter des conditions pour d'autres types de connecteurs si nécessaire (ex: MongoDB n'a pas besoin de schema strict à l'avance)
        else:
            logger.info(f"ensure_collection_or_table non applicable ou type de schéma incorrect pour le connecteur {type(connector).__name__} et la collection {collection_name}")

    async def ensure_index(self, collection_name: str, index_name: str, field_names: List[str], unique: bool = False, connector_alias: Optional[str] = None) -> None:
        """S'assure qu'un index existe."""
        connector = self.get_connector(connector_alias)
        if isinstance(connector, SQLiteConnector):
            await connector.ensure_index(collection_name, index_name, field_names, unique)
        # Ajouter des conditions pour d'autres types de connecteurs
        else:
            logger.info(f"ensure_index non implémenté ou non applicable pour le connecteur {type(connector).__name__} sur la collection {collection_name}")

    # --- Autres méthodes utilitaires ---
    # async def clean_data_in_collection(self, collection_name: str, connector_alias: Optional[str] = None):
    #     """Nettoie les données d'une collection en utilisant le service de nettoyage."""
    #     if not hasattr(self, 'cleaning_service')):
    #         logger.warning("Service de nettoyage non initialisé.")
    #         return
    #     all_data = await self.retrieve_data(collection_name, connector_alias=connector_alias)
    #     # ... logique de nettoyage et de remise à jour ...
    #     pass

# Exemple d'utilisation
async def main_data_manager_example():
    from acp768.core.logging_setup import setup_logging
    log_dir_dm = "/home/ubuntu/acp768_project/logs_test_datamanager"
    setup_logging(log_dir=log_dir_dm)
    logger.info("--- Démarrage de l'exemple DataManager ---")

    # Créer une configuration factice
    default_config_content = """
[Databases]
sqlite_main_enabled = true
sqlite_main_default = true
sqlite_logs_enabled = true

[DB_SQLITE_MAIN]
db_path = /home/ubuntu/acp768_project/data/app_main.db

[DB_SQLITE_LOGS]
db_path = /home/ubuntu/acp768_project/data/app_logs.db
    """
    config_file_path = "/home/ubuntu/acp768_project/config/test_dm_config.ini"
    os.makedirs(os.path.dirname(config_file_path), exist_ok=True)
    with open(config_file_path, "w") as f:
        f.write(default_config_content)
    
    config = ConfigLoader(default_config_path=config_file_path)
    data_manager = DataManager(config_loader=config)

    try:
        await data_manager.connect_all()

        # Utiliser le connecteur par défaut (sqlite_main)
        main_db_alias = data_manager._default_connector_alias
        logs_db_alias = "sqlite_logs"

        # Définir un schéma pour une table dans la DB principale
        prices_schema = "id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT, price REAL, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP, UNIQUE(symbol, timestamp)"
        await data_manager.ensure_collection_or_table("market_prices", prices_schema, connector_alias=main_db_alias)
        await data_manager.ensure_index("market_prices", "idx_prices_symbol", ["symbol"], connector_alias=main_db_alias)

        # Stocker des données
        await data_manager.store_data("market_prices", {"symbol": "BTC/USD", "price": 62000.0}, unique_identifier_fields=["symbol", "timestamp"], connector_alias=main_db_alias)
        await data_manager.store_data("market_prices", {"symbol": "ETH/USD", "price": 4100.50}, unique_identifier_fields=["symbol", "timestamp"], connector_alias=main_db_alias)

        # Récupérer des données
        btc_prices = await data_manager.retrieve_data("market_prices", filters={"symbol": "BTC/USD"}, projection=["symbol", "price"], connector_alias=main_db_alias)
        print(f"Prix BTC/USD récupérés: {btc_prices}")

        all_prices = await data_manager.retrieve_data("market_prices", limit=5, projection=["symbol", "price"], connector_alias=main_db_alias)
        print(f"Tous les prix (limite 5): {all_prices}")

        # Définir un schéma pour une table de logs dans l'autre DB
        app_logs_schema = "id INTEGER PRIMARY KEY AUTOINCREMENT, level TEXT, message TEXT, timestamp DATETIME DEFAULT CURRENT_TIMESTAMP"
        await data_manager.ensure_collection_or_table("application_logs", app_logs_schema, connector_alias=logs_db_alias)
        await data_manager.store_data("application_logs", {"level": "INFO", "message": "Application démarrée"}, connector_alias=logs_db_alias)
        
        app_logs = await data_manager.retrieve_data("application_logs", limit=1, sort_by=[("timestamp", -1)], connector_alias=logs_db_alias)
        print(f"Dernier log applicatif: {app_logs}")

    except Exception as e:
        logger.error(f"Erreur dans l'exemple DataManager: {e}", exc_info=True)
    finally:
        await data_manager.disconnect_all()
        # Nettoyage des fichiers de config et de DB de test
        # if os.path.exists(config_file_path): os.remove(config_file_path)
        # if os.path.exists("/home/ubuntu/acp768_project/data/app_main.db"): os.remove("/home/ubuntu/acp768_project/data/app_main.db")
        # if os.path.exists("/home/ubuntu/acp768_project/data/app_logs.db"): os.remove("/home/ubuntu/acp768_project/data/app_logs.db")

if __name__ == "__main__":
    asyncio.run(main_data_manager_example())

