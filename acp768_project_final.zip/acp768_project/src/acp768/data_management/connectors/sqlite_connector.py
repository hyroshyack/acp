# src/acp768/data_management/connectors/sqlite_connector.py
import aiosqlite
import asyncio
import logging
import os
from typing import Any, List, Dict, Optional

from .base_connector import BaseDBConnector

logger = logging.getLogger("acp768.data_management.sqlite_connector")

class SQLiteConnector(BaseDBConnector):
    """Connecteur pour interagir avec une base de données SQLite."""

    def _initialize_connector(self) -> None:
        """Initialise les informations nécessaires pour la connexion SQLite."""
        self.db_path: Optional[str] = self.config.get("db_path")
        if not self.db_path:
            logger.error("Le chemin de la base de données SQLite (db_path) n'est pas spécifié dans la configuration.")
            raise ValueError("db_path manquant pour SQLiteConnector")
        
        # S'assurer que le répertoire pour la base de données existe
        db_dir = os.path.dirname(self.db_path)
        if db_dir and not os.path.exists(db_dir):
            try:
                os.makedirs(db_dir, exist_ok=True)
                logger.info(f"Répertoire de base de données créé : {db_dir}")
            except OSError as e:
                logger.error(f"Impossible de créer le répertoire pour la base de données SQLite {db_dir}: {e}")
                raise
        self.connection: Optional[aiosqlite.Connection] = None

    async def connect(self) -> None:
        """Établit la connexion à la base de données SQLite."""
        if self.connection and not self.connection._closed:
            logger.info("Déjà connecté à SQLite.")
            return
        try:
            self.connection = await aiosqlite.connect(self.db_path)
            logger.info(f"Connecté avec succès à la base de données SQLite : {self.db_path}")
        except Exception as e:
            logger.error(f"Erreur lors de la connexion à SQLite ({self.db_path}): {e}", exc_info=True)
            self.connection = None # S'assurer que la connexion est None en cas d'échec
            raise

    async def disconnect(self) -> None:
        """Ferme la connexion à la base de données SQLite."""
        if self.connection and not self.connection._closed:
            try:
                await self.connection.close()
                logger.info(f"Déconnecté de la base de données SQLite : {self.db_path}")
            except Exception as e:
                logger.error(f"Erreur lors de la déconnexion de SQLite ({self.db_path}): {e}", exc_info=True)
            finally:
                self.connection = None
        else:
            logger.info("Aucune connexion SQLite active à fermer.")

    async def _execute_query(self, query: str, params: tuple = (), fetch_one: bool = False, fetch_all: bool = False, commit: bool = False) -> Any:
        """Exécute une requête SQL et gère la connexion."""
        if not self.is_connected():
            await self.connect()
        if not self.connection: # Vérification après tentative de connexion
             logger.error("Impossible d'exécuter la requête, aucune connexion SQLite active.")
             raise ConnectionError("Pas de connexion SQLite active.")

        try:
            async with self.connection.cursor() as cursor:
                await cursor.execute(query, params)
                if commit:
                    await self.connection.commit()
                    return cursor.rowcount # Pour INSERT, UPDATE, DELETE, retourne le nombre de lignes affectées
                if fetch_one:
                    return await cursor.fetchone()
                if fetch_all:
                    return await cursor.fetchall()
                return None # Pour les requêtes qui ne retournent rien et ne committent pas (ex: CREATE TABLE)
        except Exception as e:
            logger.error(f"Erreur lors de l'exécution de la requête SQLite \"{query}\" avec params {params}: {e}", exc_info=True)
            raise

    async def ensure_table(self, table_name: str, columns_definition: str) -> None:
        """S'assure qu'une table existe avec la définition de colonnes donnée."""
        # ATTENTION: Ne pas utiliser de f-string directement avec table_name ou columns_definition
        # si ces valeurs peuvent provenir d'une source non fiable pour éviter l'injection SQL.
        # Ici, on suppose qu'elles sont contrôlées en interne.
        safe_table_name = table_name.replace('`','').replace(';','') # Nettoyage basique
        query = f"CREATE TABLE IF NOT EXISTS `{safe_table_name}` ({columns_definition})"
        await self._execute_query(query)
        logger.info(f"Table `{safe_table_name}` assurée.")

    async def ensure_index(self, table_name: str, index_name: str, field_names: List[str], unique: bool = False) -> None:
        """S'assure qu'un index existe."""
        safe_table_name = table_name.replace('`','').replace(';','')
        safe_index_name = index_name.replace('`','').replace(';','')
        safe_field_names = ", ".join([f.replace('`','').replace(';','') for f in field_names])
        unique_str = "UNIQUE" if unique else ""
        query = f"CREATE {unique_str} INDEX IF NOT EXISTS `{safe_index_name}` ON `{safe_table_name}` ({safe_field_names})"
        await self._execute_query(query)
        logger.info(f"Index `{safe_index_name}` sur la table `{safe_table_name}` ({safe_field_names}) assuré.")

    async def store_data(self, table_name: str, data: Dict[str, Any], unique_identifier_fields: Optional[List[str]] = None) -> bool:
        """Stocke (insert ou upsert) des données dans la table spécifiée."""
        safe_table_name = table_name.replace('`','').replace(';','')
        columns = ', '.join(f'`{k}`' for k in data.keys())
        placeholders = ', '.join(['?'] * len(data))
        values = tuple(data.values())

        if unique_identifier_fields:
            # Logique d'Upsert: Tenter une mise à jour, si échoue (ou 0 ligne affectée), insérer.
            # SQLite gère cela plus nativement avec INSERT OR REPLACE ou INSERT ... ON CONFLICT DO UPDATE
            conflict_fields = ', '.join(f'`{field}`' for field in unique_identifier_fields)
            update_assignments = ', '.join(f'`{k}` = excluded.`{k}`' for k in data.keys() if k not in unique_identifier_fields)
            # Si tous les champs sont dans unique_identifier_fields, il n'y a rien à mettre à jour, juste à vérifier l'existence.
            # Dans ce cas, un simple INSERT OR IGNORE ou une vérification préalable serait mieux.
            # Pour un upsert général :
            if not update_assignments: # Tous les champs font partie de l'identifiant unique
                 query = f"INSERT OR IGNORE INTO `{safe_table_name}` ({columns}) VALUES ({placeholders})"
            else:
                query = f"INSERT INTO `{safe_table_name}` ({columns}) VALUES ({placeholders}) \
                          ON CONFLICT({conflict_fields}) DO UPDATE SET {update_assignments}"
        else:
            query = f"INSERT INTO `{safe_table_name}` ({columns}) VALUES ({placeholders})"
        
        try:
            rowcount = await self._execute_query(query, values, commit=True)
            logger.debug(f"{rowcount} ligne(s) affectée(s) dans `{safe_table_name}` pour les données: {data}")
            return rowcount > 0 if rowcount is not None else True # True si INSERT OR IGNORE et que ça existe déjà
        except Exception as e:
            logger.error(f"Erreur lors du stockage des données dans `{safe_table_name}`: {e}", exc_info=True)
            return False

    async def retrieve_data(
        self, 
        table_name: str, 
        filters: Optional[Dict[str, Any]] = None, 
        sort_by: Optional[List[tuple[str, int]]] = None,
        limit: Optional[int] = None,
        projection: Optional[List[str]] = None,
        custom_where_clause: Optional[str] = None,
        custom_params: tuple = ()
    ) -> List[Dict[str, Any]]:
        """Récupère des données de la table spécifiée."""
        safe_table_name = table_name.replace('`','').replace(';','')
        
        if projection:
            select_fields = ', '.join(f'`{f}`' for f in projection)
        else:
            select_fields = "*"
        
        query = f"SELECT {select_fields} FROM `{safe_table_name}`"
        params = list(custom_params)

        where_clauses = []
        if filters:
            for key, value in filters.items():
                # Gérer les opérateurs simples comme >, <, LIKE etc. si nécessaire
                if isinstance(value, dict) and "$in" in value: # Pour les clauses IN
                    placeholders = ",".join("?" for _ in value["$in"])
                    where_clauses.append(f"`{key}` IN ({placeholders})")
                    params.extend(value["$in"])
                else:
                    where_clauses.append(f"`{key}` = ?")
                    params.append(value)
        
        if custom_where_clause:
            where_clauses.append(f"({custom_where_clause})") # Parenthèses pour la priorité

        if where_clauses:
            query += " WHERE " + " AND ".join(where_clauses)
        
        if sort_by:
            order_by_clauses = []
            for field, direction in sort_by:
                order_by_clauses.append(f"`{field}` {"ASC" if direction == 1 else "DESC"}")
            query += " ORDER BY " + ", ".join(order_by_clauses)
        
        if limit is not None:
            query += " LIMIT ?"
            params.append(limit)

        try:
            rows = await self._execute_query(query, tuple(params), fetch_all=True)
            if rows and self.connection:
                # Obtenir les noms de colonnes à partir de la description du curseur
                # Ceci est un peu un hack car aiosqlite.Row n'est pas directement un dict
                # et cursor.description n'est pas directement accessible après fetchall sans refaire un curseur
                # Une solution plus propre serait de wrapper aiosqlite.Row ou de parser la première ligne
                # Pour l'instant, on va supposer que les colonnes sont dans l'ordre de `projection` ou toutes les colonnes
                # Si `projection` est None, il faut récupérer les noms de colonnes autrement.
                # Une méthode plus robuste est d'utiliser `self.connection.row_factory = aiosqlite.Row` avant la connexion
                # et ensuite `dict(row)` fonctionne.
                # Pour cet exemple, nous allons le faire manuellement si pas de projection.
                if not projection:
                    # Récupérer les noms de colonnes si pas de projection
                    async with self.connection.execute(f"PRAGMA table_info(`{safe_table_name}`)") as pragma_cursor:
                        table_info_rows = await pragma_cursor.fetchall()
                        column_names = [info[1] for info in table_info_rows]
                else:
                    column_names = projection
                
                return [dict(zip(column_names, row)) for row in rows]
            return []
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des données de `{safe_table_name}`: {e}", exc_info=True)
            return []

    async def update_data(
        self, 
        table_name: str, 
        filters: Dict[str, Any], 
        update_fields: Dict[str, Any],
        upsert: bool = False # Upsert est géré par store_data avec unique_identifier_fields pour SQLite
    ) -> int:
        """Met à jour des données. Pour SQLite, l'upsert est mieux géré via store_data."""
        safe_table_name = table_name.replace('`','').replace(';','')
        if not update_fields:
            logger.warning("Aucun champ à mettre à jour fourni.")
            return 0
        if not filters:
            logger.error("Aucun filtre fourni pour l'opération de mise à jour. Opération annulée pour la sécurité.")
            return 0 # Empêche la mise à jour de toute la table par erreur

        set_clauses = []
        params = []
        for key, value in update_fields.items():
            set_clauses.append(f"`{key}` = ?")
            params.append(value)
        
        where_clauses = []
        for key, value in filters.items():
            where_clauses.append(f"`{key}` = ?")
            params.append(value)
        
        query = f"UPDATE `{safe_table_name}` SET {', '.join(set_clauses)} WHERE {', '.join(where_clauses)}"
        
        try:
            rowcount = await self._execute_query(query, tuple(params), commit=True)
            return rowcount if rowcount is not None else 0
        except Exception as e:
            logger.error(f"Erreur lors de la mise à jour des données dans `{safe_table_name}`: {e}", exc_info=True)
            return 0

    async def delete_data(self, table_name: str, filters: Dict[str, Any]) -> int:
        """Supprime des données."""
        safe_table_name = table_name.replace('`','').replace(';','')
        if not filters:
            logger.error("Aucun filtre fourni pour l'opération de suppression. Opération annulée pour la sécurité.")
            return 0 # Empêche la suppression de toute la table par erreur

        where_clauses = []
        params = []
        for key, value in filters.items():
            where_clauses.append(f"`{key}` = ?")
            params.append(value)
        
        query = f"DELETE FROM `{safe_table_name}` WHERE {', '.join(where_clauses)}"

        try:
            rowcount = await self._execute_query(query, tuple(params), commit=True)
            return rowcount if rowcount is not None else 0
        except Exception as e:
            logger.error(f"Erreur lors de la suppression des données de `{safe_table_name}`: {e}", exc_info=True)
            return 0

    def is_connected(self) -> bool:
        return self.connection is not None and not self.connection._closed

# Exemple d'utilisation
async def main_sqlite_example():
    # Configurer le logging pour voir les sorties
    from acp768.core.logging_setup import setup_logging
    log_dir_sqlite = "/home/ubuntu/acp768_project/logs_test_sqlite"
    setup_logging(log_dir=log_dir_sqlite)
    logger.info("--- Démarrage de l'exemple SQLiteConnector ---")

    db_file = "/home/ubuntu/acp768_project/data/test_database.db"
    # S'assurer que le répertoire data existe
    os.makedirs(os.path.dirname(db_file), exist_ok=True)
    
    config = {"db_path": db_file}
    connector = SQLiteConnector(config)

    try:
        await connector.connect()
        print(f"Connecté: {connector.is_connected()}")

        # Assurer une table
        await connector.ensure_table(
            "market_prices", 
            """id INTEGER PRIMARY KEY AUTOINCREMENT, 
               symbol TEXT NOT NULL, 
               price REAL NOT NULL, 
               timestamp DATETIME DEFAULT CURRENT_TIMESTAMP, 
               UNIQUE(symbol, timestamp)"""
        )
        await connector.ensure_index("market_prices", "idx_symbol_price", ["symbol", "price"])

        # Stocker des données (Upsert)
        data1 = {"symbol": "BTC/USD", "price": 60000.50}
        data2 = {"symbol": "ETH/USD", "price": 4000.75}
        data_btc_update = {"symbol": "BTC/USD", "price": 60500.00, "timestamp": "2024-05-08 10:00:00"} # Timestamp manuel
        
        await connector.store_data("market_prices", data1, unique_identifier_fields=["symbol", "timestamp"]) # timestamp sera auto
        await connector.store_data("market_prices", data2, unique_identifier_fields=["symbol", "timestamp"])
        # Pour simuler un upsert sur un enregistrement existant (basé sur symbol et timestamp), il faudrait récupérer le timestamp auto
        # Ou utiliser une logique plus complexe. Ici, on va insérer un nouvel enregistrement avec un timestamp manuel.
        await connector.store_data("market_prices", data_btc_update, unique_identifier_fields=["symbol", "timestamp"])

        # Récupérer des données
        print("\n--- Toutes les données BTC/USD ---")
        btc_data = await connector.retrieve_data("market_prices", filters={"symbol": "BTC/USD"}, projection=["symbol", "price", "timestamp"])
        for row in btc_data:
            print(row)

        print("\n--- Toutes les données, triées par prix décroissant, limite 2 ---")
        all_data_sorted = await connector.retrieve_data(
            "market_prices", 
            sort_by=[("price", -1)], 
            limit=2,
            projection=["symbol", "price"]
        )
        for row in all_data_sorted:
            print(row)
        
        print("\n--- Données avec prix > 5000 ---")
        high_price_data = await connector.retrieve_data(
            "market_prices",
            custom_where_clause="price > ?",
            custom_params=(5000,),
            projection=["symbol", "price"]
        )
        for row in high_price_data:
            print(row)

        # Mettre à jour des données
        print("\n--- Mise à jour du prix ETH/USD ---")
        updated_count = await connector.update_data(
            "market_prices", 
            filters={"symbol": "ETH/USD"}, 
            update_fields={"price": 4100.00}
        )
        print(f"{updated_count} ligne(s) mise(s) à jour pour ETH/USD.")
        eth_updated = await connector.retrieve_data("market_prices", filters={"symbol": "ETH/USD"}, projection=["symbol", "price"])
        print(eth_updated)

        # Supprimer des données
        # print("\n--- Suppression des données BTC/USD avec prix < 60500 ---")
        # deleted_count = await connector.delete_data("market_prices", filters={"symbol": "BTC/USD", "price": ("<", 60500)})
        # print(f"{deleted_count} ligne(s) supprimée(s) pour BTC/USD.")
        # btc_after_delete = await connector.retrieve_data("market_prices", filters={"symbol": "BTC/USD"})
        # print(btc_after_delete)

    except Exception as e:
        logger.error(f"Une erreur s'est produite dans l'exemple principal SQLite: {e}", exc_info=True)
    finally:
        if connector:
            await connector.disconnect()
            print(f"Déconnecté à la fin: {not connector.is_connected()}")
        # Supprimer le fichier de base de données de test après l'exécution
        # if os.path.exists(db_file):
        #     os.remove(db_file)
        #     logger.info(f"Fichier de base de données de test supprimé: {db_file}")

if __name__ == "__main__":
    asyncio.run(main_sqlite_example())

