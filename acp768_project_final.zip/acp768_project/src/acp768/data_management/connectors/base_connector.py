# src/acp768/data_management/connectors/base_connector.py
from abc import ABC, abstractmethod
from typing import Any, List, Dict, Optional

class BaseDBConnector(ABC):
    """Classe de base abstraite pour les connecteurs de base de données."""

    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.connection: Optional[Any] = None
        self._initialize_connector()

    @abstractmethod
    def _initialize_connector(self) -> None:
        """Initialise le connecteur spécifique (par exemple, établit la connexion)."""
        pass

    @abstractmethod
    async def connect(self) -> None:
        """Établit la connexion à la base de données."""
        pass

    @abstractmethod
    async def disconnect(self) -> None:
        """Ferme la connexion à la base de données."""
        pass

    @abstractmethod
    async def store_data(self, collection_name: str, data: Dict[str, Any], unique_identifier: Optional[Dict[str, Any]] = None) -> bool:
        """
        Stocke une seule entrée de données dans la collection spécifiée.

        Args:
            collection_name: Nom de la table/collection où stocker les données.
            data: Dictionnaire représentant les données à stocker.
            unique_identifier: Dictionnaire des champs qui identifient de manière unique l'enregistrement pour une mise à jour/upsert.
                               Si None, une simple insertion est tentée.

        Returns:
            True si le stockage a réussi, False sinon.
        """
        pass

    @abstractmethod
    async def retrieve_data(
        self, 
        collection_name: str, 
        filters: Optional[Dict[str, Any]] = None, 
        sort_by: Optional[List[tuple[str, int]]] = None, # Liste de (champ, direction (1 asc, -1 desc))
        limit: Optional[int] = None,
        projection: Optional[Dict[str, int]] = None # ex: {"_id": 0, "name": 1}
    ) -> List[Dict[str, Any]]:
        """
        Récupère des données de la collection spécifiée en fonction des filtres.

        Args:
            collection_name: Nom de la table/collection.
            filters: Dictionnaire de filtres à appliquer.
            sort_by: Liste de tuples pour le tri.
            limit: Nombre maximum d'enregistrements à retourner.
            projection: Spécifie les champs à inclure ou exclure.

        Returns:
            Une liste de dictionnaires représentant les données récupérées.
        """
        pass

    @abstractmethod
    async def update_data(
        self, 
        collection_name: str, 
        filters: Dict[str, Any], 
        update_data: Dict[str, Any],
        upsert: bool = False
    ) -> int:
        """
        Met à jour des données dans la collection spécifiée.

        Args:
            collection_name: Nom de la table/collection.
            filters: Dictionnaire de filtres pour identifier les documents à mettre à jour.
            update_data: Dictionnaire des champs à mettre à jour.
            upsert: Si True, insère le document si aucun ne correspond aux filtres.

        Returns:
            Le nombre de documents modifiés.
        """
        pass

    @abstractmethod
    async def delete_data(self, collection_name: str, filters: Dict[str, Any]) -> int:
        """
        Supprime des données de la collection spécifiée.

        Args:
            collection_name: Nom de la table/collection.
            filters: Dictionnaire de filtres pour identifier les documents à supprimer.

        Returns:
            Le nombre de documents supprimés.
        """
        pass

    async def ensure_index(self, collection_name: str, field_name: str, unique: bool = False) -> None:
        """Assure qu'un index existe sur un champ donné (optionnel à implémenter par les connecteurs)."""
        pass

    def is_connected(self) -> bool:
        """Vérifie si le connecteur est actuellement connecté."""
        return self.connection is not None

