# src/acp768/blockchain_integration/api_handler.py
import asyncio
import logging
from typing import Any, Dict, Optional, List, Union, Type

from web3.types import BlockIdentifier, TxReceipt, Wei, Address, HexStr

from acp768.core.config_loader import ConfigLoader
from acp768.core.event_bus import EventBus
from .node_interface import NodeInterface
from .erigon_node import ErigonNode
from .infura_node import InfuraNode

logger = logging.getLogger("acp768.blockchain_integration.api_handler")

class APIHandler:
    """
    Gère la communication avec les nœuds blockchain (Ethereum).
    Permet de sélectionner un nœud actif et de basculer entre les nœuds configurés.
    """

    def __init__(self, config_loader: ConfigLoader, event_bus: Optional[EventBus] = None):
        self.config_loader = config_loader
        self.event_bus = event_bus
        self._nodes: Dict[str, NodeInterface] = {}
        self._active_node_alias: Optional[str] = None
        self._node_priority: List[str] = [] # Ordre de préférence des nœuds

        self._initialize_nodes()

    def _initialize_nodes(self) -> None:
        """Initialise les instances de nœuds basées sur la configuration."""
        node_configs_section = self.config_loader.get_section("BlockchainNodes")
        if not node_configs_section:
            logger.warning("Aucune configuration de nœud blockchain trouvée dans [BlockchainNodes].")
            return

        # Lire les priorités si définies
        priority_str = node_configs_section.get("node_priority_order", "")
        if priority_str:
            self._node_priority = [alias.strip() for alias in priority_str.split(",") if alias.strip()]
            logger.info(f"Ordre de priorité des nœuds défini : {self._node_priority}")

        for alias, node_type_or_url in node_configs_section.items():
            if alias.endswith("_enabled") or alias.endswith("_url") or alias.endswith("_project_id") or alias.endswith("_network") or alias == "node_priority_order":
                continue # Clés de configuration, pas des alias de nœud direct

            is_enabled = self.config_loader.get_boolean("BlockchainNodes", f"{alias}_enabled", fallback=False)
            if not is_enabled:
                logger.info(f"Nœud blockchain ások{alias}" est désactivé dans la configuration.")
                continue

            node_url = self.config_loader.get("BlockchainNodes", f"{alias}_url")
            node_type = node_configs_section.get(alias, "").lower() # Le type peut être directement la valeur de l_alias
            
            if not node_url:
                logger.error(f"URL manquante pour le nœud ások{alias}" (clé: {alias}_url).")
                continue

            node_instance: Optional[NodeInterface] = None
            request_timeout = self.config_loader.get_int("BlockchainNodes", "default_request_timeout", fallback=30)

            if node_type == "erigon":
                node_instance = ErigonNode(node_url=node_url, node_name=alias, request_timeout=request_timeout)
            elif node_type == "infura":
                project_id = self.config_loader.get("BlockchainNodes", f"{alias}_project_id")
                network = self.config_loader.get("BlockchainNodes", f"{alias}_network", fallback="mainnet")
                if not project_id:
                    logger.error(f"Project ID manquant pour le nœud Infura ások{alias}" (clé: {alias}_project_id).")
                    continue
                # L_URL pour InfuraNode est souvent construite, mais on peut aussi passer l_URL complète
                # Si l_URL fournie ne contient pas déjà le project_id, InfuraNode essaiera de le gérer.
                node_instance = InfuraNode(node_url=node_url, project_id=project_id, node_name=alias, request_timeout=request_timeout, network=network)
            else:
                logger.warning(f"Type de nœud blockchain non supporté ou non spécifié pour l_alias ások{alias}": {node_type}. URL: {node_url}")
                # On pourrait tenter une connexion générique si l_URL est complète et le type est implicite
                # Pour l_instant, on ignore si le type n_est pas explicitement géré.
                continue
            
            if node_instance:
                self._nodes[alias] = node_instance
                logger.info(f"Nœud blockchain ások{alias}" ({node_type}) initialisé avec l_URL: {node_url}")
                if not self._node_priority: # Si aucune priorité n_est définie, ajouter dans l_ordre de lecture
                    self._node_priority.append(alias)
        
        if not self._nodes:
            logger.error("Aucun nœud blockchain n_a pu être initialisé. Vérifiez la configuration [BlockchainNodes].")
        else:
            logger.info(f"Nœuds blockchain initialisés: {list(self._nodes.keys())}")
            logger.info(f"Ordre de tentative de connexion des nœuds (basé sur la priorité ou la config): {self._node_priority}")

    async def connect_to_active_node(self) -> bool:
        """Tente de se connecter au premier nœud disponible selon l_ordre de priorité."""
        if self._active_node_alias and self._nodes[self._active_node_alias].is_connected():
            logger.info(f"Déjà connecté au nœud actif: {self._active_node_alias}")
            return True

        for alias in self._node_priority:
            if alias in self._nodes:
                node = self._nodes[alias]
                logger.info(f"Tentative de connexion au nœud: {alias} ({node.get_node_url()})")
                try:
                    if await node.connect():
                        if await node.is_synced(): # Vérifier la synchronisation après connexion
                            self._active_node_alias = alias
                            logger.info(f"Connecté avec succès et synchronisé au nœud actif: {alias}")
                            if self.event_bus:
                                await self.event_bus.publish_async("BLOCKCHAIN_NODE_CONNECTED", node_alias=alias, node_url=node.get_node_url())
                            return True
                        else:
                            logger.warning(f"Nœud {alias} connecté mais non synchronisé. Tentative avec le prochain nœud.")
                            await node.disconnect() # Déconnecter si non synchronisé pour ne pas l_utiliser
                    else:
                        logger.warning(f"Échec de la connexion au nœud {alias}. Tentative avec le prochain nœud.")
                except Exception as e:
                    logger.error(f"Erreur lors de la tentative de connexion au nœud {alias}: {e}", exc_info=True)
                    # S_assurer que le nœud est marqué comme déconnecté en cas d_erreur
                    if node.is_connected(): 
                        await node.disconnect()
            else:
                logger.warning(f"L_alias de nœud ások{alias}" de la liste de priorité n_a pas été trouvé dans les nœuds initialisés.")
        
        logger.error("Impossible de se connecter à un nœud blockchain fonctionnel et synchronisé.")
        self._active_node_alias = None
        if self.event_bus:
            await self.event_bus.publish_async("BLOCKCHAIN_CONNECTION_FAILED")
        return False

    async def disconnect_all_nodes(self) -> None:
        """Déconnecte tous les nœuds initialisés."""
        for alias, node in self._nodes.items():
            if node.is_connected():
                try:
                    await node.disconnect()
                except Exception as e:
                    logger.error(f"Erreur lors de la déconnexion du nœud {alias}: {e}", exc_info=True)
        self._active_node_alias = None
        logger.info("Tous les nœuds blockchain ont été déconnectés.")

    def get_active_node(self) -> Optional[NodeInterface]:
        """Retourne l_instance du nœud actif."""
        if self._active_node_alias and self._active_node_alias in self._nodes:
            node = self._nodes[self._active_node_alias]
            if node.is_connected():
                return node
            else:
                logger.warning(f"Le nœud actif ások{self._active_node_alias}" n_est plus connecté. Il faut se reconnecter.")
                # On pourrait tenter une reconnexion ici ou laisser connect_to_active_node gérer cela
                self._active_node_alias = None 
                return None
        logger.warning("Aucun nœud blockchain actif disponible.")
        return None

    # --- Méthodes déléguées au nœud actif --- 
    # Ces méthodes devraient vérifier si un nœud actif existe et est connecté.
    # Une gestion d_erreur robuste ou une tentative de reconnexion pourrait être ajoutée ici.

    async def _execute_on_active_node(self, method_name: str, *args, **kwargs) -> Any:
        """Exécute une méthode sur le nœud actif, gérant la connexion et les erreurs."""
        active_node = self.get_active_node()
        if not active_node:
            logger.info("Aucun nœud actif. Tentative de connexion...")
            if not await self.connect_to_active_node():
                logger.error(f"Impossible d_exécuter {method_name}: Aucun nœud actif disponible après tentative de connexion.")
                return None # Ou lever une exception spécifique
            active_node = self.get_active_node() # Récupérer le nœud nouvellement activé
            if not active_node: # Double vérification
                logger.error(f"Impossible d_exécuter {method_name}: get_active_node a retourné None même après reconnexion.")
                return None

        try:
            method = getattr(active_node, method_name)
            return await method(*args, **kwargs)
        except ProviderConnectionError as pce:
            logger.error(f"Erreur de connexion au provider lors de l_appel de {method_name} sur {active_node.get_node_name()}: {pce}. Tentative de basculement.")
            await active_node.disconnect() # Marquer comme déconnecté
            self._active_node_alias = None
            if await self.connect_to_active_node(): # Tenter de basculer vers un autre nœud
                logger.info(f"Basculement réussi vers un nouveau nœud. Nouvelle tentative de {method_name}...")
                return await self._execute_on_active_node(method_name, *args, **kwargs) # Réessayer la méthode
            else:
                logger.error(f"Échec du basculement de nœud après erreur de connexion. {method_name} a échoué.")
                return None
        except Exception as e:
            logger.error(f"Erreur lors de l_exécution de {method_name} sur le nœud {active_node.get_node_name()}: {e}", exc_info=True)
            return None # Ou lever une exception plus spécifique

    async def get_latest_block_number(self) -> Optional[int]:
        return await self._execute_on_active_node("get_latest_block_number")

    async def get_block(self, block_identifier: BlockIdentifier, full_transactions: bool = False) -> Optional[Dict[str, Any]]:
        return await self._execute_on_active_node("get_block", block_identifier, full_transactions=full_transactions)

    async def get_balance(self, address: Address) -> Optional[Wei]:
        return await self._execute_on_active_node("get_balance", address)

    async def get_transaction_receipt(self, tx_hash: HexStr) -> Optional[TxReceipt]:
        return await self._execute_on_active_node("get_transaction_receipt", tx_hash)

    async def get_gas_price(self) -> Optional[Wei]:
        return await self._execute_on_active_node("get_gas_price")

    async def estimate_gas(self, transaction: Dict[str, Any]) -> Optional[int]:
        return await self._execute_on_active_node("estimate_gas", transaction)

    async def send_raw_transaction(self, raw_tx: HexStr) -> Optional[HexStr]:
        return await self._execute_on_active_node("send_raw_transaction", raw_tx)

    async def call_contract_function(self, contract_address: Address, abi: List[Dict[str, Any]], function_name: str, args: Optional[List[Any]] = None, block_identifier: BlockIdentifier = "latest") -> Any:
        return await self._execute_on_active_node("call_contract_function", contract_address, abi, function_name, args=args, block_identifier=block_identifier)

    async def get_contract_events(self, contract_address: Address, abi: List[Dict[str, Any]], event_name: str, from_block: Optional[BlockIdentifier] = "earliest", to_block: Optional[BlockIdentifier] = "latest", argument_filters: Optional[Dict[str, Any]] = None) -> Optional[List[Dict[str, Any]]]:
        return await self._execute_on_active_node("get_contract_events", contract_address, abi, event_name, from_block=from_block, to_block=to_block, argument_filters=argument_filters)

    async def is_active_node_synced(self) -> bool:
        # Cette méthode est un peu différente car elle concerne l_état du nœud actif lui-même
        active_node = self.get_active_node()
        if not active_node:
            logger.warning("Aucun nœud actif pour vérifier la synchronisation.")
            # Tenter de se connecter si aucun nœud n_est actif
            if not await self.connect_to_active_node():
                return False # Impossible de se connecter à un nœud synchronisé
            active_node = self.get_active_node()
            if not active_node: return False # Toujours pas de nœud après tentative
        
        try:
            return await active_node.is_synced()
        except Exception as e:
            logger.error(f"Erreur lors de la vérification de la synchronisation du nœud actif {active_node.get_node_name()}: {e}", exc_info=True)
            return False

# Exemple d_utilisation
async def main_api_handler_example():
    from acp768.core.logging_setup import setup_logging
    import os
    log_dir_apih = "/home/ubuntu/acp768_project/logs_test_apihandler"
    setup_logging(log_dir=log_dir_apih)
    logger.info("--- Démarrage de l_exemple APIHandler ---")

    # Créer une configuration factice pour APIHandler
    # Assurez-vous que les URL et Project ID sont valides pour les tests
    infura_project_id_env = os.getenv("INFURA_PROJECT_ID", "YOUR_INFURA_PROJECT_ID_HERE_APIH")
    if infura_project_id_env == "YOUR_INFURA_PROJECT_ID_HERE_APIH":
        logger.warning("INFURA_PROJECT_ID non défini pour le test APIHandler. Le test Infura échouera probablement.")

    default_config_content = f"""
[BlockchainNodes]
# Ordre de préférence pour la connexion
node_priority_order = erigon_local, infura_sepolia

# Nœud Erigon local (exemple, adaptez l_URL si vous en avez un)
erigon_local = erigon
erigon_local_enabled = true
erigon_local_url = http://localhost:8545 
# erigon_local_url = https://rpc.sepolia.org # Test avec un nœud public si pas d_Erigon local

# Nœud Infura Sepolia
infura_sepolia = infura
infura_sepolia_enabled = true
infura_sepolia_url = wss://sepolia.infura.io/ws/v3/{infura_project_id_env}
infura_sepolia_project_id = {infura_project_id_env}
infura_sepolia_network = sepolia

default_request_timeout = 20
    """
    config_file_path = "/home/ubuntu/acp768_project/config/test_apihandler_config.ini"
    os.makedirs(os.path.dirname(config_file_path), exist_ok=True)
    with open(config_file_path, "w") as f:
        f.write(default_config_content)
    
    config = ConfigLoader(default_config_path=config_file_path)
    event_bus_instance = EventBus() # Optionnel, pour les notifications
    api_handler = APIHandler(config_loader=config, event_bus=event_bus_instance)

    try:
        if await api_handler.connect_to_active_node():
            active_node_instance = api_handler.get_active_node()
            if active_node_instance:
                print(f"Connecté au nœud actif: {active_node_instance.get_node_name()} ({active_node_instance.get_node_url()})")
                print(f"Nœud actif synchronisé: {await api_handler.is_active_node_synced()}")

                latest_block = await api_handler.get_latest_block_number()
                print(f"Dernier bloc via APIHandler: {latest_block}")

                # Adresse exemple (Vitalik Buterin)
                example_address = "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045"
                balance = await api_handler.get_balance(example_address)
                if balance is not None:
                    print(f"Solde de {example_address}: {Web3.from_wei(balance, "ether")} ETH")
            else:
                print("Aucun nœud actif trouvé même après une connexion réussie signalée.")
        else:
            print("Échec de la connexion à un nœud actif via APIHandler.")

    except Exception as e:
        logger.error(f"Une erreur s_est produite dans l_exemple principal APIHandler: {e}", exc_info=True)
    finally:
        await api_handler.disconnect_all_nodes()
        print("APIHandler a déconnecté tous les nœuds.")
        # if os.path.exists(config_file_path): os.remove(config_file_path)

if __name__ == "__main__":
    # Nécessite web3 et aiohttp, aiosqlite (indirectement via les exemples précédents)
    # `pip install web3 aiohttp`
    # Pour exécuter cet exemple, assurez-vous d_avoir une variable d_environnement INFURA_PROJECT_ID
    # ou remplacez "YOUR_INFURA_PROJECT_ID_HERE_APIH" par votre ID de projet Infura.
    # export INFURA_PROJECT_ID="votre_id_projet"
    asyncio.run(main_api_handler_example())

