# src/acp768/blockchain_integration/erigon_node.py
import asyncio
import logging
from typing import Any, Dict, Optional, List, Union

from web3 import Web3, AsyncHTTPProvider, WebsocketProvider
from web3.eth import AsyncEth
from web3.exceptions import ProviderConnectionError, TransactionNotFound, BlockNotFound
from web3.types import BlockIdentifier, TxReceipt, Wei, Address, HexStr, RPCEndpoint

from .node_interface import NodeInterface

logger = logging.getLogger("acp768.blockchain_integration.erigon_node")

class ErigonNode(NodeInterface):
    """Implémentation de NodeInterface pour un nœud Erigon (ou compatible Ethereum)."""

    def __init__(self, node_url: str, node_name: str = "ErigonNode", request_timeout: int = 30):
        super().__init__(node_url, node_name)
        self.request_timeout = request_timeout
        self.web3: Optional[Web3] = None

    async def connect(self) -> bool:
        """Établit la connexion au nœud Erigon."""
        if self.is_connected_flag and self.web3 and self.web3.is_connected():
            logger.info(f"Déjà connecté à {self.node_name} sur {self.node_url}")
            return True
        
        logger.info(f"Tentative de connexion à {self.node_name} sur {self.node_url}...")
        try:
            if self.node_url.startswith("ws://") or self.node_url.startswith("wss://"):
                # Pour les connexions WebSocket, il est préférable d'utiliser `persistent_websocket_provider`
                # ou de gérer la reconnexion manuellement car `WebsocketProvider` peut ne pas être stable pour de longues durées.
                # Pour cet exemple, nous utilisons le WebsocketProvider standard.
                provider = WebsocketProvider(self.node_url, websocket_timeout=self.request_timeout)
            elif self.node_url.startswith("http://") or self.node_url.startswith("https://"):
                provider = AsyncHTTPProvider(self.node_url, request_kwargs={"timeout": self.request_timeout})
            else:
                logger.error(f"URL de nœud non supportée pour ErigonNode: {self.node_url}. Doit commencer par http(s):// ou ws(s)://")
                self.is_connected_flag = False
                return False

            self.web3 = Web3(provider, modules={"eth": (AsyncEth,)}, middlewares=[])
            
            # Test de connexion
            if await self.web3.is_connected():
                self.is_connected_flag = True
                logger.info(f"Connecté avec succès à {self.node_name} sur {self.node_url}")
                # Afficher la version du client pour confirmation (optionnel)
                # try:
                #     client_version = await self.web3.client_version
                #     logger.info(f"Version du client {self.node_name}: {client_version}")
                # except Exception as e:
                #     logger.warning(f"Impossible de récupérer la version du client: {e}")
                return True
            else:
                logger.error(f"Échec de la connexion à {self.node_name} sur {self.node_url}. web3.is_connected() a retourné False.")
                self.is_connected_flag = False
                # Tenter de fermer le provider si l'objet web3 a été créé
                if hasattr(self.web3.provider, 'disconnect'): # Pour AsyncHTTPProvider
                    await self.web3.provider.disconnect()
                elif hasattr(self.web3.provider, 'close'): # Pour certains providers WebSocket
                     await self.web3.provider.close()
                self.web3 = None
                return False
        except ProviderConnectionError as e:
            logger.error(f"Erreur de connexion au provider {self.node_name} ({self.node_url}): {e}", exc_info=True)
            self.is_connected_flag = False
            self.web3 = None
            return False
        except Exception as e:
            logger.error(f"Erreur inattendue lors de la connexion à {self.node_name} ({self.node_url}): {e}", exc_info=True)
            self.is_connected_flag = False
            self.web3 = None
            return False

    async def disconnect(self) -> None:
        """Ferme la connexion au nœud Erigon."""
        if self.web3 and self.web3.provider:
            logger.info(f"Déconnexion de {self.node_name} sur {self.node_url}...")
            try:
                if hasattr(self.web3.provider, 'disconnect'): # Pour AsyncHTTPProvider
                    await self.web3.provider.disconnect()
                elif hasattr(self.web3.provider, 'close'): # Pour certains providers WebSocket
                     await self.web3.provider.close()
                logger.info(f"Déconnecté de {self.node_name}.")
            except Exception as e:
                logger.error(f"Erreur lors de la déconnexion de {self.node_name}: {e}", exc_info=True)
            finally:
                self.web3 = None
                self.is_connected_flag = False
        else:
            logger.info(f"{self.node_name} n'est pas connecté ou n'a pas de provider.")
            self.is_connected_flag = False # S'assurer que le flag est correct

    async def _ensure_connected(self):
        if not self.is_connected_flag or not self.web3 or not await self.web3.is_connected():
            logger.warning(f"{self.node_name} n'est pas connecté. Tentative de reconnexion...")
            await self.connect()
            if not self.is_connected_flag:
                raise ProviderConnectionError(f"Impossible de se connecter ou de se reconnecter à {self.node_name} sur {self.node_url}")
        # Vérification supplémentaire pour s'assurer que web3.eth est disponible
        if not hasattr(self.web3, 'eth'):
             raise AttributeError(f"L'objet Web3 pour {self.node_name} n'a pas d'attribut 'eth'. La connexion a peut-être échoué silencieusement.")

    async def get_latest_block_number(self) -> Optional[int]:
        await self._ensure_connected()
        try:
            return await self.web3.eth.block_number
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du dernier numéro de bloc depuis {self.node_name}: {e}", exc_info=True)
            return None

    async def get_block(self, block_identifier: BlockIdentifier, full_transactions: bool = False) -> Optional[Dict[str, Any]]:
        await self._ensure_connected()
        try:
            block_data = await self.web3.eth.get_block(block_identifier, full_transactions=full_transactions)
            return dict(block_data) # Convertir AttributeDict en dict standard
        except BlockNotFound:
            logger.warning(f"Bloc {block_identifier} non trouvé sur {self.node_name}.")
            return None
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du bloc {block_identifier} depuis {self.node_name}: {e}", exc_info=True)
            return None

    async def get_balance(self, address: Address) -> Optional[Wei]:
        await self._ensure_connected()
        try:
            checksum_address = Web3.to_checksum_address(address)
            return await self.web3.eth.get_balance(checksum_address)
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du solde pour l'adresse {address} depuis {self.node_name}: {e}", exc_info=True)
            return None

    async def get_transaction_receipt(self, tx_hash: HexStr) -> Optional[TxReceipt]:
        await self._ensure_connected()
        try:
            receipt = await self.web3.eth.get_transaction_receipt(tx_hash)
            return receipt # C'est déjà un dict-like object (AttributeDict)
        except TransactionNotFound:
            logger.warning(f"Reçu de transaction non trouvé pour le hash {tx_hash} sur {self.node_name}.")
            return None
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du reçu de transaction {tx_hash} depuis {self.node_name}: {e}", exc_info=True)
            return None

    async def get_gas_price(self) -> Optional[Wei]:
        await self._ensure_connected()
        try:
            return await self.web3.eth.gas_price
        except Exception as e:
            logger.error(f"Erreur lors de la récupération du prix du gaz depuis {self.node_name}: {e}", exc_info=True)
            return None

    async def estimate_gas(self, transaction: Dict[str, Any]) -> Optional[int]:
        await self._ensure_connected()
        try:
            # S'assurer que 'from' et 'to' sont des adresses checksumées si présentes
            if 'from' in transaction:
                transaction['from'] = Web3.to_checksum_address(transaction['from'])
            if 'to' in transaction:
                transaction['to'] = Web3.to_checksum_address(transaction['to'])
            return await self.web3.eth.estimate_gas(transaction)
        except ValueError as ve: # Souvent levé pour des erreurs de transaction (ex: revert)
            logger.warning(f"Erreur de valeur lors de l'estimation du gaz pour la transaction sur {self.node_name}: {ve}. La transaction pourrait revert.")
            # Tenter d'extraire plus d'informations si possible (dépend du nœud et de web3.py)
            # if hasattr(ve, 'data') and ve.data:
            #     logger.warning(f"  Données d'erreur de l'estimation du gaz: {ve.data}")
            return None
        except Exception as e:
            logger.error(f"Erreur lors de l'estimation du gaz pour la transaction sur {self.node_name}: {e}", exc_info=True)
            return None

    async def send_raw_transaction(self, raw_tx: HexStr) -> Optional[HexStr]:
        await self._ensure_connected()
        try:
            tx_hash = await self.web3.eth.send_raw_transaction(raw_tx)
            return tx_hash
        except Exception as e:
            logger.error(f"Erreur lors de l'envoi de la transaction brute sur {self.node_name}: {e}", exc_info=True)
            return None

    async def call_contract_function(
        self, 
        contract_address: Address, 
        abi: List[Dict[str, Any]], 
        function_name: str, 
        args: Optional[List[Any]] = None,
        block_identifier: BlockIdentifier = 'latest'
    ) -> Any:
        await self._ensure_connected()
        try:
            checksum_contract_address = Web3.to_checksum_address(contract_address)
            contract = self.web3.eth.contract(address=checksum_contract_address, abi=abi)
            func_obj = contract.functions[function_name](*(args if args else []))
            return await func_obj.call(block_identifier=block_identifier)
        except Exception as e:
            logger.error(f"Erreur lors de l'appel de la fonction de contrat ások{function_name}" sur {contract_address} via {self.node_name}: {e}", exc_info=True)
            return None

    async def get_contract_events(
        self,
        contract_address: Address,
        abi: List[Dict[str, Any]],
        event_name: str,
        from_block: Optional[BlockIdentifier] = "earliest", # Par défaut à earliest pour récupérer tous les événements
        to_block: Optional[BlockIdentifier] = "latest",
        argument_filters: Optional[Dict[str, Any]] = None
    ) -> Optional[List[Dict[str, Any]]]:
        await self._ensure_connected()
        try:
            checksum_contract_address = Web3.to_checksum_address(contract_address)
            contract = self.web3.eth.contract(address=checksum_contract_address, abi=abi)
            event = getattr(contract.events, event_name)
            
            event_filter = await event.create_filter(
                fromBlock=from_block, 
                toBlock=to_block, 
                argument_filters=argument_filters
            )
            logs = await event_filter.get_all_entries()
            # Web3.py v6+ retourne directement une liste de AttributeDict, qui sont dict-like
            return [dict(log) for log in logs]
        except Exception as e:
            logger.error(f"Erreur lors de la récupération des événements ások{event_name}" du contrat {contract_address} via {self.node_name}: {e}", exc_info=True)
            return None

    async def is_synced(self) -> bool:
        await self._ensure_connected()
        try:
            sync_status = await self.web3.eth.syncing
            if isinstance(sync_status, bool) and not sync_status:
                # Si eth_syncing retourne False, le nœud est synchronisé.
                return True
            elif isinstance(sync_status, dict):
                # Si c'est un dictionnaire, le nœud est en cours de synchronisation.
                logger.info(f"{self.node_name} est en cours de synchronisation: {sync_status}")
                return False
            logger.warning(f"Statut de synchronisation inattendu de {self.node_name}: {sync_status}")
            return False # Par prudence
        except Exception as e:
            logger.error(f"Erreur lors de la vérification de la synchronisation de {self.node_name}: {e}", exc_info=True)
            return False # Supposer non synchronisé en cas d'erreur

# Exemple d'utilisation (nécessite un nœud Erigon en cours d'exécution)
async def main_erigon_example():
    from acp768.core.logging_setup import setup_logging
    log_dir_erigon = "/home/ubuntu/acp768_project/logs_test_erigon"
    setup_logging(log_dir=log_dir_erigon)
    logger.info("--- Démarrage de l'exemple ErigonNode ---")

    # Remplacer par l'URL de votre nœud Erigon local (HTTP ou WebSocket)
    # Pour les tests, un nœud de testnet public peut être utilisé, mais les performances peuvent varier.
    # erigon_url = "http://localhost:8545" # Exemple local
    erigon_url = "https://rpc.sepolia.org" # Nœud public Sepolia pour test (peut être lent ou limité)
    
    node = ErigonNode(node_url=erigon_url, node_name="SepoliaTestNode")

    try:
        if await node.connect():
            print(f"Connecté à: {node.get_node_name()} ({node.get_node_url()})")
            print(f"Est synchronisé: {await node.is_synced()}")
            
            latest_block = await node.get_latest_block_number()
            print(f"Dernier bloc: {latest_block}")

            if latest_block:
                block_info = await node.get_block(latest_block)
                if block_info:
                    print(f"Infos du dernier bloc ({latest_block}): Timestamp {block_info.get('timestamp')}, Hash {block_info.get('hash').hex()[:10]}...")
            
            # Adresse exemple (Vitalik Buterin)
            example_address = "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045"
            balance = await node.get_balance(example_address)
            if balance is not None:
                print(f"Solde de {example_address}: {Web3.from_wei(balance, 'ether')} ETH")
            
            gas_price = await node.get_gas_price()
            if gas_price is not None:
                print(f"Prix actuel du gaz: {Web3.from_wei(gas_price, 'gwei')} Gwei")

            # Exemple d'appel de contrat (lecture seule) - Contrat WETH sur Sepolia
            weth_sepolia_address = "0x7b79995e5f793A07Bc00c21412e50Ea00A78Acca" # WETH sur Sepolia
            erc20_abi_simplified = [
                {"constant":True,"inputs":[],"name":"name","outputs":[{"name":"","type":"string"}],"payable":False,"stateMutability":"view","type":"function"},
                {"constant":True,"inputs":[],"name":"symbol","outputs":[{"name":"","type":"string"}],"payable":False,"stateMutability":"view","type":"function"},
                {"constant":True,"inputs":[{"name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"name":"balance","type":"uint256"}],"payable":False,"stateMutability":"view","type":"function"}
            ]
            token_name = await node.call_contract_function(weth_sepolia_address, erc20_abi_simplified, "name")
            print(f"Nom du token WETH (Sepolia): {token_name}")
            
            # Récupérer des événements (exemple basique, peut ne rien retourner si pas d'événements récents)
            # Pour un test réel, il faudrait un contrat qui émet des événements et des transactions qui les déclenchent.
            # events = await node.get_contract_events(weth_sepolia_address, erc20_abi_simplified, "Transfer", from_block=latest_block - 10 if latest_block else "latest", to_block="latest")
            # if events:
            #     print(f"Derniers événements 'Transfer' pour WETH (Sepolia): {events[:2]}") # Afficher les 2 premiers
            # else:
            #     print("Aucun événement 'Transfer' récent trouvé pour WETH (Sepolia).")

        else:
            print(f"Échec de la connexion à {node.get_node_name()}.")

    except Exception as e:
        logger.error(f"Une erreur s'est produite dans l'exemple principal ErigonNode: {e}", exc_info=True)
    finally:
        await node.disconnect()
        print(f"Déconnecté à la fin: {not node.is_connected()}")

if __name__ == "__main__":
    asyncio.run(main_erigon_example())

