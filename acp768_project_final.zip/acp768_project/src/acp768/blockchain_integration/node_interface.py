# src/acp768/blockchain_integration/node_interface.py
from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, List, Union
from web3.types import BlockIdentifier, TxReceipt, Wei, Address, HexStr

class NodeInterface(ABC):
    """Interface abstraite pour les interactions avec un nœud blockchain (Ethereum)."""

    def __init__(self, node_url: str, node_name: str):
        self.node_url = node_url
        self.node_name = node_name
        self.web3_provider: Optional[Any] = None # Sera une instance de Web3
        self.is_connected_flag: bool = False

    @abstractmethod
    async def connect(self) -> bool:
        """Établit la connexion au nœud."""
        pass

    @abstractmethod
    async def disconnect(self) -> None:
        """Ferme la connexion au nœud."""
        pass

    def is_connected(self) -> bool:
        """Vérifie si le nœud est actuellement connecté."""
        return self.is_connected_flag

    @abstractmethod
    async def get_latest_block_number(self) -> Optional[int]:
        """Récupère le numéro du dernier bloc."""
        pass

    @abstractmethod
    async def get_block(self, block_identifier: BlockIdentifier, full_transactions: bool = False) -> Optional[Dict[str, Any]]:
        """Récupère les informations d'un bloc."""
        pass

    @abstractmethod
    async def get_balance(self, address: Address) -> Optional[Wei]:
        """Récupère le solde d'une adresse."""
        pass

    @abstractmethod
    async def get_transaction_receipt(self, tx_hash: HexStr) -> Optional[TxReceipt]:
        """Récupère le reçu d'une transaction."""
        pass

    @abstractmethod
    async def get_gas_price(self) -> Optional[Wei]:
        """Récupère le prix actuel du gaz."""
        pass

    @abstractmethod
    async def estimate_gas(self, transaction: Dict[str, Any]) -> Optional[int]:
        """Estime le gaz nécessaire pour une transaction."""
        pass

    @abstractmethod
    async def send_raw_transaction(self, raw_tx: HexStr) -> Optional[HexStr]:
        """Envoie une transaction brute signée."""
        pass

    @abstractmethod
    async def call_contract_function(
        self, 
        contract_address: Address, 
        abi: List[Dict[str, Any]], 
        function_name: str, 
        args: Optional[List[Any]] = None,
        # from_address: Optional[Address] = None # Pour les appels qui ne modifient pas l'état
    ) -> Any:
        """Appelle une fonction de lecture (read-only) d'un contrat intelligent."""
        pass
    
    @abstractmethod
    async def get_contract_events(
        self,
        contract_address: Address,
        abi: List[Dict[str, Any]],
        event_name: str,
        from_block: Optional[BlockIdentifier] = "latest",
        to_block: Optional[BlockIdentifier] = "latest",
        argument_filters: Optional[Dict[str, Any]] = None
    ) -> Optional[List[Dict[str, Any]]]:
        """Récupère les événements émis par un contrat."""
        pass

    @abstractmethod
    async def is_synced(self) -> bool:
        """Vérifie si le nœud est synchronisé avec le réseau."""
        pass

    def get_node_name(self) -> str:
        return self.node_name

    def get_node_url(self) -> str:
        return self.node_url

