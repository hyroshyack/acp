# src/acp768/blockchain_integration/infura_node.py
import asyncio
import logging
from typing import Any, Dict, Optional, List, Union

from web3 import Web3, AsyncHTTPProvider, WebsocketProvider
from web3.eth import AsyncEth
from web3.exceptions import ProviderConnectionError, TransactionNotFound, BlockNotFound
from web3.types import BlockIdentifier, TxReceipt, Wei, Address, HexStr

from .node_interface import NodeInterface

logger = logging.getLogger("acp768.blockchain_integration.infura_node")

class InfuraNode(NodeInterface):
    """Implémentation de NodeInterface pour un nœud Infura (ou compatible Ethereum via Infura)."""

    def __init__(self, node_url: str, project_id: str, node_name: str = "InfuraNode", request_timeout: int = 30, network: str = "mainnet"):
        # L_URL d_Infura typique est wss://<network>.infura.io/ws/v3/<project_id>
        # ou https://<network>.infura.io/v3/<project_id>
        # On s_assure que l_URL fournie est bien formatée ou on la construit.
        
        # Vérifier si l_URL contient déjà le project_id pour éviter la duplication
        if project_id not in node_url:
            if "infura.io/ws/v3/" in node_url or "infura.io/v3/" in node_url:
                 # L_URL semble être un template sans project_id, on le logue comme un avertissement
                 logger.warning(f"L_URL du nœud Infura ások{node_url}" semble être un template. Le project_id ások{project_id}" sera ajouté.")
                 # On essaie de le construire correctement, en supposant que l_URL est la base
                 if node_url.endswith("infura.io/ws/v3/"):
                     node_url = f"{node_url}{project_id}"
                 elif node_url.endswith("infura.io/v3/"):
                     node_url = f"{node_url}{project_id}"
                 else: # Cas moins certain, on concatène simplement
                     logger.warning(f"Impossible de déterminer comment insérer le project_id dans ások{node_url}". Concaténation simple.")
                     node_url = f"{node_url}{project_id}" # Peut ne pas être correct
            else: # Si ce n_est pas une URL Infura standard, on utilise l_URL telle quelle, en espérant qu_elle soit complète
                logger.info(f"Utilisation de l_URL de nœud personnalisée ások{node_url}" pour InfuraNode.")
        
        super().__init__(node_url, node_name)
        self.project_id = project_id # Peut être utilisé pour des vérifications ou des constructions d_URL plus tard
        self.request_timeout = request_timeout
        self.web3: Optional[Web3] = None
        self.network = network # ex: "mainnet", "sepolia"

    async def connect(self) -> bool:
        if self.is_connected_flag and self.web3 and self.web3.is_connected():
            logger.info(f"Déjà connecté à {self.node_name} sur {self.node_url}")
            return True
        
        logger.info(f"Tentative de connexion à {self.node_name} ({self.network}) sur {self.node_url}...")
        try:
            if self.node_url.startswith("wss://") or self.node_url.startswith("ws://"):
                provider = WebsocketProvider(self.node_url, websocket_timeout=self.request_timeout)
            elif self.node_url.startswith("https://") or self.node_url.startswith("http://"):
                provider = AsyncHTTPProvider(self.node_url, request_kwargs={"timeout": self.request_timeout})
            else:
                logger.error(f"URL de nœud non supportée pour InfuraNode: {self.node_url}. Doit commencer par http(s):// ou ws(s)://")
                self.is_connected_flag = False
                return False

            self.web3 = Web3(provider, modules={"eth": (AsyncEth,)}, middlewares=[])
            
            if await self.web3.is_connected():
                self.is_connected_flag = True
                logger.info(f"Connecté avec succès à {self.node_name} ({self.network}) sur {self.node_url}")
                return True
            else:
                logger.error(f"Échec de la connexion à {self.node_name} ({self.network}) sur {self.node_url}. web3.is_connected() a retourné False.")
                self.is_connected_flag = False
                if hasattr(self.web3.provider, "disconnect"): await self.web3.provider.disconnect()
                elif hasattr(self.web3.provider, "close"): await self.web3.provider.close()
                self.web3 = None
                return False
        except ProviderConnectionError as e:
            logger.error(f"Erreur de connexion au provider {self.node_name} ({self.node_url}): {e}", exc_info=True)
            self.is_connected_flag = False
            self.web3 = None
            return False
        except Exception as e:
            logger.error(f"Erreur inattendue lors de la connexion à {self.node_name} ({self.node_url}): {e}", exc_info=True)
            self.is_connected_flag = False
            self.web3 = None
            return False

    async def disconnect(self) -> None:
        if self.web3 and self.web3.provider:
            logger.info(f"Déconnexion de {self.node_name} sur {self.node_url}...")
            try:
                if hasattr(self.web3.provider, "disconnect"): await self.web3.provider.disconnect()
                elif hasattr(self.web3.provider, "close"): await self.web3.provider.close()
                logger.info(f"Déconnecté de {self.node_name}.")
            except Exception as e:
                logger.error(f"Erreur lors de la déconnexion de {self.node_name}: {e}", exc_info=True)
            finally:
                self.web3 = None
                self.is_connected_flag = False
        else:
            logger.info(f"{self.node_name} n_est pas connecté ou n_a pas de provider.")
            self.is_connected_flag = False

    async def _ensure_connected(self):
        if not self.is_connected_flag or not self.web3 or not await self.web3.is_connected():
            logger.warning(f"{self.node_name} n_est pas connecté. Tentative de reconnexion...")
            await self.connect()
            if not self.is_connected_flag:
                raise ProviderConnectionError(f"Impossible de se connecter ou de se reconnecter à {self.node_name} sur {self.node_url}")
        if not hasattr(self.web3, "eth"):
             raise AttributeError(f"L_objet Web3 pour {self.node_name} n_a pas d_attribut eth. Connexion échouée ?")

    async def get_latest_block_number(self) -> Optional[int]:
        await self._ensure_connected()
        try:
            return await self.web3.eth.block_number
        except Exception as e:
            logger.error(f"Erreur get_latest_block_number ({self.node_name}): {e}", exc_info=True)
            return None

    async def get_block(self, block_identifier: BlockIdentifier, full_transactions: bool = False) -> Optional[Dict[str, Any]]:
        await self._ensure_connected()
        try:
            block_data = await self.web3.eth.get_block(block_identifier, full_transactions=full_transactions)
            return dict(block_data)
        except BlockNotFound:
            logger.warning(f"Bloc {block_identifier} non trouvé sur {self.node_name}.")
            return None
        except Exception as e:
            logger.error(f"Erreur get_block ({self.node_name}): {e}", exc_info=True)
            return None

    async def get_balance(self, address: Address) -> Optional[Wei]:
        await self._ensure_connected()
        try:
            checksum_address = Web3.to_checksum_address(address)
            return await self.web3.eth.get_balance(checksum_address)
        except Exception as e:
            logger.error(f"Erreur get_balance ({self.node_name}): {e}", exc_info=True)
            return None

    async def get_transaction_receipt(self, tx_hash: HexStr) -> Optional[TxReceipt]:
        await self._ensure_connected()
        try:
            return await self.web3.eth.get_transaction_receipt(tx_hash)
        except TransactionNotFound:
            logger.warning(f"Reçu de transaction non trouvé pour {tx_hash} sur {self.node_name}.")
            return None
        except Exception as e:
            logger.error(f"Erreur get_transaction_receipt ({self.node_name}): {e}", exc_info=True)
            return None

    async def get_gas_price(self) -> Optional[Wei]:
        await self._ensure_connected()
        try:
            return await self.web3.eth.gas_price
        except Exception as e:
            logger.error(f"Erreur get_gas_price ({self.node_name}): {e}", exc_info=True)
            return None

    async def estimate_gas(self, transaction: Dict[str, Any]) -> Optional[int]:
        await self._ensure_connected()
        try:
            if "from" in transaction: transaction["from"] = Web3.to_checksum_address(transaction["from"])
            if "to" in transaction: transaction["to"] = Web3.to_checksum_address(transaction["to"])
            return await self.web3.eth.estimate_gas(transaction)
        except ValueError as ve:
            logger.warning(f"Erreur de valeur estimate_gas ({self.node_name}): {ve}. Transaction pourrait revert.")
            return None
        except Exception as e:
            logger.error(f"Erreur estimate_gas ({self.node_name}): {e}", exc_info=True)
            return None

    async def send_raw_transaction(self, raw_tx: HexStr) -> Optional[HexStr]:
        await self._ensure_connected()
        try:
            return await self.web3.eth.send_raw_transaction(raw_tx)
        except Exception as e:
            logger.error(f"Erreur send_raw_transaction ({self.node_name}): {e}", exc_info=True)
            return None

    async def call_contract_function(
        self, 
        contract_address: Address, 
        abi: List[Dict[str, Any]], 
        function_name: str, 
        args: Optional[List[Any]] = None,
        block_identifier: BlockIdentifier = "latest"
    ) -> Any:
        await self._ensure_connected()
        try:
            checksum_contract_address = Web3.to_checksum_address(contract_address)
            contract = self.web3.eth.contract(address=checksum_contract_address, abi=abi)
            func_obj = contract.functions[function_name](*(args if args else []))
            return await func_obj.call(block_identifier=block_identifier)
        except Exception as e:
            logger.error(f"Erreur call_contract_function ások{function_name}" sur {contract_address} ({self.node_name}): {e}", exc_info=True)
            return None

    async def get_contract_events(
        self,
        contract_address: Address,
        abi: List[Dict[str, Any]],
        event_name: str,
        from_block: Optional[BlockIdentifier] = "earliest",
        to_block: Optional[BlockIdentifier] = "latest",
        argument_filters: Optional[Dict[str, Any]] = None
    ) -> Optional[List[Dict[str, Any]]]:
        await self._ensure_connected()
        try:
            checksum_contract_address = Web3.to_checksum_address(contract_address)
            contract = self.web3.eth.contract(address=checksum_contract_address, abi=abi)
            event = getattr(contract.events, event_name)
            event_filter = await event.create_filter(
                fromBlock=from_block, 
                toBlock=to_block, 
                argument_filters=argument_filters
            )
            logs = await event_filter.get_all_entries()
            return [dict(log) for log in logs]
        except Exception as e:
            logger.error(f"Erreur get_contract_events ások{event_name}" sur {contract_address} ({self.node_name}): {e}", exc_info=True)
            return None

    async def is_synced(self) -> bool:
        await self._ensure_connected()
        try:
            sync_status = await self.web3.eth.syncing
            if isinstance(sync_status, bool) and not sync_status:
                return True
            elif isinstance(sync_status, dict):
                logger.info(f"{self.node_name} est en cours de synchronisation: {sync_status}")
                return False
            logger.warning(f"Statut de synchronisation inattendu de {self.node_name}: {sync_status}")
            return False
        except Exception as e:
            logger.error(f"Erreur is_synced ({self.node_name}): {e}", exc_info=True)
            return False

# Exemple d_utilisation (nécessite un PROJECT_ID Infura valide)
async def main_infura_example():
    from acp768.core.logging_setup import setup_logging
    log_dir_infura = "/home/ubuntu/acp768_project/logs_test_infura"
    setup_logging(log_dir=log_dir_infura)
    logger.info("--- Démarrage de l_exemple InfuraNode ---")

    # Remplacez par votre Project ID Infura et le réseau souhaité (ex: "sepolia")
    infura_project_id = os.getenv("INFURA_PROJECT_ID", "YOUR_INFURA_PROJECT_ID_HERE")
    if infura_project_id == "YOUR_INFURA_PROJECT_ID_HERE":
        logger.warning("Veuillez définir la variable d_environnement INFURA_PROJECT_ID ou remplacer la valeur par défaut pour tester InfuraNode.")
        return

    network = "sepolia"
    # Infura URL peut être construite ou fournie entièrement
    infura_ws_url = f"wss://{network}.infura.io/ws/v3/{infura_project_id}"
    # infura_http_url = f"https://{network}.infura.io/v3/{infura_project_id}"

    node = InfuraNode(node_url=infura_ws_url, project_id=infura_project_id, node_name=f"InfuraSepoliaTestNode", network=network)

    try:
        if await node.connect():
            print(f"Connecté à: {node.get_node_name()} ({node.get_node_url()})")
            print(f"Est synchronisé: {await node.is_synced()}")
            
            latest_block = await node.get_latest_block_number()
            print(f"Dernier bloc ({network}): {latest_block}")

            # Adresse exemple (Vitalik Buterin)
            example_address = "0xd8dA6BF26964aF9D7eEd9e03E53415D37aA96045"
            balance = await node.get_balance(example_address)
            if balance is not None:
                print(f"Solde de {example_address} sur {network}: {Web3.from_wei(balance, "ether")} ETH")
        else:
            print(f"Échec de la connexion à {node.get_node_name()}.")

    except Exception as e:
        logger.error(f"Une erreur s_est produite dans l_exemple principal InfuraNode: {e}", exc_info=True)
    finally:
        await node.disconnect()
        print(f"Déconnecté à la fin: {not node.is_connected()}")

if __name__ == "__main__":
    # Pour exécuter cet exemple, assurez-vous d_avoir une variable d_environnement INFURA_PROJECT_ID
    # ou remplacez "YOUR_INFURA_PROJECT_ID_HERE" par votre ID de projet Infura.
    # export INFURA_PROJECT_ID="votre_id_projet"
    import os # Ajout de l_import os pour getenv
    asyncio.run(main_infura_example())

