# src/acp768/core/logging_setup.py
import logging
import logging.config
import os
import sys
from typing import Optional

# Tentative d'importation de la configuration pour déterminer le chemin des logs
# Cela crée une dépendance circulaire si logging_setup est importé avant que config soit initialisé globalement.
# Il est préférable de passer le chemin du fichier de config de logging ou les paramètres directement.

DEFAULT_LOGGING_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "detailed": {
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(module)s:%(lineno)d - %(message)s",
            "datefmt": "%Y-%m-%d %H:%M:%S"
        },
        "simple": {
            "format": "%(asctime)s - %(levelname)s - %(message)s",
            "datefmt": "%Y-%m-%d %H:%M:%S"
        }
    },
    "handlers": {
        "console": {
            "class": "logging.StreamHandler",
            "level": "INFO",
            "formatter": "simple",
            "stream": "ext://sys.stdout"
        },
        "file_general": {
            "class": "logging.handlers.RotatingFileHandler",
            "level": "DEBUG",
            "formatter": "detailed",
            "filename": "/tmp/acp768_general.log",  # Chemin par défaut, devrait être configurable
            "maxBytes": 10485760,  # 10MB
            "backupCount": 5,
            "encoding": "utf-8"
        },
        "file_trading": {
            "class": "logging.handlers.RotatingFileHandler",
            "level": "INFO",
            "formatter": "detailed",
            "filename": "/tmp/acp768_trading.log", # Chemin par défaut, devrait être configurable
            "maxBytes": 5242880,  # 5MB
            "backupCount": 3,
            "encoding": "utf-8"
        }
    },
    "loggers": {
        "acp768": { # Logger racine pour l'application
            "handlers": ["console", "file_general"],
            "level": "DEBUG",
            "propagate": False
        },
        "acp768.trading_engine": {
            "handlers": ["file_trading"],
            "level": "INFO",
            "propagate": True # Propage vers le logger acp768 pour la console et le fichier général
        }
        # D'autres loggers spécifiques peuvent être ajoutés ici
    },
    "root": { # Logger racine global (si des bibliothèques tierces logguent)
        "handlers": ["console"],
        "level": "WARNING"
    }
}

def setup_logging(
    config_path: Optional[str] = None,
    default_level: int = logging.INFO,
    config_dict: Optional[dict] = None,
    log_dir: Optional[str] = None
) -> None:
    """
    Configure le logging pour l'application.

    La configuration peut être chargée depuis un fichier INI (via config_path),
    un dictionnaire Python (via config_dict), ou utiliser une configuration par défaut.
    Le paramètre log_dir permet de spécifier dynamiquement le répertoire des fichiers de log.
    """
    if config_dict:
        # Si un dictionnaire de configuration est fourni, l'utiliser directement.
        # Mettre à jour les chemins des fichiers de log si log_dir est spécifié.
        if log_dir:
            for handler_name, handler_config in config_dict.get("handlers", {}).items():
                if "filename" in handler_config:
                    original_filename = os.path.basename(handler_config["filename"])
                    handler_config["filename"] = os.path.join(log_dir, original_filename)
                    os.makedirs(os.path.dirname(handler_config["filename"]), exist_ok=True)
        logging.config.dictConfig(config_dict)
        print(f"Logging configuré avec le dictionnaire fourni. Logs dans: {log_dir if log_dir else 'chemins par défaut'}")

    elif config_path and os.path.exists(config_path):
        # Si un chemin vers un fichier de configuration INI est fourni et existe.
        # Note: logging.config.fileConfig ne permet pas de modifier dynamiquement les chemins aussi facilement
        # que dictConfig. Il faudrait parser le fichier INI manuellement pour changer les chemins si log_dir est utilisé.
        # Pour simplifier, on suppose que le fichier INI contient déjà les bons chemins ou qu'on utilise dictConfig.
        try:
            logging.config.fileConfig(config_path, disable_existing_loggers=False)
            print(f"Logging configuré avec le fichier : {config_path}")
        except Exception as e:
            print(f"Erreur lors de la configuration du logging depuis {config_path}: {e}. Utilisation de la configuration par défaut.", file=sys.stderr)
            setup_logging(default_level=default_level, config_dict=DEFAULT_LOGGING_CONFIG, log_dir=log_dir)

    else:
        # Utiliser la configuration par défaut (DEFAULT_LOGGING_CONFIG).
        if config_path:
            print(f"Avertissement : Fichier de configuration de logging introuvable : {config_path}. Utilisation de la configuration par défaut.", file=sys.stderr)
        else:
            print("Aucun fichier de configuration de logging spécifié. Utilisation de la configuration par défaut.", file=sys.stderr)
        
        current_config = DEFAULT_LOGGING_CONFIG.copy()
        if log_dir:
            for handler_name, handler_config in current_config.get("handlers", {}).items():
                if "filename" in handler_config:
                    original_filename = os.path.basename(handler_config["filename"])
                    handler_config["filename"] = os.path.join(log_dir, original_filename)
                    os.makedirs(os.path.dirname(handler_config["filename"]), exist_ok=True)
        
        logging.config.dictConfig(current_config)
        print(f"Logging configuré avec les paramètres par défaut. Logs dans: {log_dir if log_dir else '/tmp'}")

    # Test après configuration
    # logging.getLogger("acp768").info("Test du logger acp768 après configuration.")
    # logging.getLogger("acp768.trading_engine").info("Test du logger acp768.trading_engine après configuration.")

# Exemple d'utilisation (typiquement appelé au début de main.py)
if __name__ == '__main__':
    # Cas 1: Utilisation de la configuration par défaut, avec un répertoire de logs spécifié
    print("--- Test avec configuration par défaut et log_dir --- ")
    test_log_dir = "/home/ubuntu/acp768_project/logs_test_default"
    setup_logging(log_dir=test_log_dir)
    logger_app_default = logging.getLogger("acp768")
    logger_trading_default = logging.getLogger("acp768.trading_engine")
    logger_app_default.debug("Message de debug pour le logger principal (devrait apparaître dans le fichier general).")
    logger_app_default.info("Message d'info pour le logger principal.")
    logger_trading_default.info("Message d'info pour le logger de trading (devrait apparaître dans le fichier trading et general).")
    logger_trading_default.warning("Message de warning pour le logger de trading.")
    print(f"Vérifiez les fichiers dans {test_log_dir}")
    # Nettoyage des handlers pour le prochain test pour éviter la duplication des logs en console
    for handler in logging.getLogger().handlers[:]: logging.getLogger().removeHandler(handler)
    for handler in logging.getLogger("acp768").handlers[:]: logging.getLogger("acp768").removeHandler(handler)
    for handler in logging.getLogger("acp768.trading_engine").handlers[:]: logging.getLogger("acp768.trading_engine").removeHandler(handler)


    # Cas 2: Utilisation d'un fichier de configuration INI
    print("\n--- Test avec fichier de configuration INI --- ")
    config_ini_content = """
[loggers]
keys=root,acp768_app

[handlers]
keys=consoleHandler,fileHandler

[formatters]
keys=simpleFormatter

[logger_root]
level=WARNING
handlers=consoleHandler

[logger_acp768_app]
level=INFO
handlers=consoleHandler,fileHandler
qualname=acp768
propagate=0

[handler_consoleHandler]
class=StreamHandler
level=INFO
formatter=simpleFormatter
args=(sys.stdout,)

[handler_fileHandler]
class=FileHandler
level=DEBUG
formatter=simpleFormatter
args=('/home/ubuntu/acp768_project/logs_test_ini/app_from_ini.log', 'w')

[formatter_simpleFormatter]
format=%(asctime)s - %(name)s - %(levelname)s - %(message)s
datefmt=%Y-%m-%d %H:%M:%S
    """
    ini_config_path = "/home/ubuntu/acp768_project/config/logging_test.ini"
    os.makedirs("/home/ubuntu/acp768_project/logs_test_ini", exist_ok=True)
    with open(ini_config_path, "w") as f:
        f.write(config_ini_content)
    
    setup_logging(config_path=ini_config_path)
    logger_from_ini = logging.getLogger("acp768") # Doit correspondre à qualname
    logger_from_ini.info("Message d'info depuis la configuration INI.")
    logger_from_ini.debug("Message de debug depuis la configuration INI (devrait apparaître dans le fichier).")
    print(f"Vérifiez le fichier /home/ubuntu/acp768_project/logs_test_ini/app_from_ini.log")
    # Nettoyage
    for handler in logging.getLogger().handlers[:]: logging.getLogger().removeHandler(handler)
    for handler in logging.getLogger("acp768").handlers[:]: logging.getLogger("acp768").removeHandler(handler)

    # Cas 3: Utilisation d'un dictionnaire de configuration personnalisé
    print("\n--- Test avec dictionnaire de configuration personnalisé --- ")
    custom_log_dir = "/home/ubuntu/acp768_project/logs_test_dict"
    custom_config_dict = {
        "version": 1,
        "disable_existing_loggers": False,
        "formatters": {
            "custom_formatter": {"format": "%(asctime)s [%(levelname)s] %(name)s: %(message)s"}
        },
        "handlers": {
            "custom_console": {
                "class": "logging.StreamHandler", "level": "DEBUG", "formatter": "custom_formatter"
            },
            "custom_file": {
                "class": "logging.FileHandler", "level": "DEBUG", "formatter": "custom_formatter",
                "filename": "app_custom.log" # Sera préfixé par custom_log_dir
            }
        },
        "loggers": {
            "my_module": {"handlers": ["custom_console", "custom_file"], "level": "DEBUG"}
        }
    }
    setup_logging(config_dict=custom_config_dict, log_dir=custom_log_dir)
    logger_custom = logging.getLogger("my_module")
    logger_custom.info("Info message from custom dict config.")
    logger_custom.debug("Debug message from custom dict config.")
    print(f"Vérifiez les fichiers dans {custom_log_dir}")


