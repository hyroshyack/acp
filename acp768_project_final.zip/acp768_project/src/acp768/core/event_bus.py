# src/acp768/core/event_bus.py
from collections import defaultdict
from typing import Callable, Any, Dict, List
import asyncio
import logging

logger = logging.getLogger("acp768.core.event_bus")

class EventBus:
    """Un bus d'événements simple pour la communication découplée entre les modules."""

    def __init__(self):
        self._listeners: Dict[str, List[Callable]] = defaultdict(list)
        self._async_listeners: Dict[str, List[Callable]] = defaultdict(list)

    def subscribe(self, event_type: str, listener: Callable) -> None:
        """
        Abonne un listener à un type d'événement spécifique.
        Le listener sera appelé de manière synchrone.

        Args:
            event_type: Le type d'événement auquel s'abonner (ex: "PRICE_UPDATE").
            listener: La fonction callback à appeler lorsque l'événement est émis.
                      Elle doit accepter *args et **kwargs.
        """
        if not callable(listener):
            raise ValueError("Le listener doit être une fonction ou une méthode appelable.")
        self._listeners[event_type].append(listener)
        logger.debug(f"Listener {listener.__name__} abonné à l'événement synchrone '{event_type}'.")

    def subscribe_async(self, event_type: str, async_listener: Callable) -> None:
        """
        Abonne un listener asynchrone (coroutine) à un type d'événement spécifique.
        Le listener sera exécuté de manière asynchrone.

        Args:
            event_type: Le type d'événement auquel s'abonner.
            async_listener: La coroutine callback à appeler.
                            Elle doit accepter *args et **kwargs.
        """
        if not asyncio.iscoroutinefunction(async_listener):
            raise ValueError("Le listener asynchrone doit être une coroutine (défini avec 'async def').")
        self._async_listeners[event_type].append(async_listener)
        logger.debug(f"Listener asynchrone {async_listener.__name__} abonné à l'événement '{event_type}'.")

    def unsubscribe(self, event_type: str, listener: Callable) -> None:
        """
        Désabonne un listener d'un type d'événement synchrone.
        """
        if event_type in self._listeners:
            try:
                self._listeners[event_type].remove(listener)
                logger.debug(f"Listener {listener.__name__} désabonné de l'événement synchrone '{event_type}'.")
                if not self._listeners[event_type]:
                    del self._listeners[event_type]
            except ValueError:
                logger.warning(f"Tentative de désabonnement d'un listener non trouvé pour l'événement synchrone '{event_type}'.")
        else:
            logger.warning(f"Tentative de désabonnement d'un événement synchrone non existant: '{event_type}'.")

    def unsubscribe_async(self, event_type: str, async_listener: Callable) -> None:
        """
        Désabonne un listener asynchrone d'un type d'événement.
        """
        if event_type in self._async_listeners:
            try:
                self._async_listeners[event_type].remove(async_listener)
                logger.debug(f"Listener asynchrone {async_listener.__name__} désabonné de l'événement '{event_type}'.")
                if not self._async_listeners[event_type]:
                    del self._async_listeners[event_type]
            except ValueError:
                logger.warning(f"Tentative de désabonnement d'un listener asynchrone non trouvé pour l'événement '{event_type}'.")
        else:
            logger.warning(f"Tentative de désabonnement d'un événement asynchrone non existant: '{event_type}'.")

    def publish(self, event_type: str, *args: Any, **kwargs: Any) -> None:
        """
        Publie un événement, notifiant tous les listeners synchrones abonnés.
        Les listeners sont appelés séquentiellement dans l'ordre de leur abonnement.
        Les exceptions levées par les listeners sont logguées mais n'arrêtent pas la notification des autres.

        Args:
            event_type: Le type d'événement à publier.
            *args: Arguments positionnels à passer aux listeners.
            **kwargs: Arguments nommés à passer aux listeners.
        """
        logger.info(f"Publication de l'événement synchrone '{event_type}' avec args: {args}, kwargs: {kwargs}")
        if event_type in self._listeners:
            for listener in self._listeners[event_type][:]:
                try:
                    listener(*args, **kwargs)
                except Exception as e:
                    logger.error(f"Erreur lors de l'appel du listener synchrone {listener.__name__} pour l'événement '{event_type}': {e}", exc_info=True)

    async def publish_async(self, event_type: str, *args: Any, **kwargs: Any) -> None:
        """
        Publie un événement, notifiant tous les listeners asynchrones abonnés.
        Les coroutines des listeners sont collectées et exécutées concouramment avec asyncio.gather.
        Les exceptions levées par les listeners sont logguées.

        Args:
            event_type: Le type d'événement à publier.
            *args: Arguments positionnels à passer aux listeners.
            **kwargs: Arguments nommés à passer aux listeners.
        """
        logger.info(f"Publication de l'événement asynchrone '{event_type}' avec args: {args}, kwargs: {kwargs}")
        if event_type in self._async_listeners:
            tasks = []
            for async_listener in self._async_listeners[event_type][:]:
                try:
                    tasks.append(async_listener(*args, **kwargs))
                except Exception as e: # Devrait être rare ici car on ne fait qu'appeler la coroutine
                    logger.error(f"Erreur lors de la création de la tâche pour le listener asynchrone {async_listener.__name__} pour l'événement '{event_type}': {e}", exc_info=True)
            
            if tasks:
                results = await asyncio.gather(*tasks, return_exceptions=True)
                for i, result in enumerate(results):
                    if isinstance(result, Exception):
                        listener_name = self._async_listeners[event_type][i].__name__ # Peut être imprécis si des désabonnements ont eu lieu
                        logger.error(f"Erreur lors de l'exécution du listener asynchrone {listener_name} pour l'événement '{event_type}': {result}", exc_info=result)

# Exemple d'utilisation (pourrait être dans des tests ou des modules spécifiques)
if __name__ == '__main__':
    # Initialisation du logging pour voir les messages du bus d'événements
    from acp768.core.logging_setup import setup_logging
    setup_logging(log_dir="/home/ubuntu/acp768_project/logs_test_eventbus")
    
    event_bus = EventBus()

    # Listeners synchrones
    def simple_listener(message: str, source: str = "unknown"):
        print(f"[Simple Listener] Message reçu: '{message}' de {source}")

    def another_listener(data: Dict[str, Any]):
        print(f"[Another Listener] Données reçues: {data}")
        if data.get("value", 0) < 0:
            raise ValueError("La valeur ne peut pas être négative dans another_listener")

    event_bus.subscribe("USER_LOGIN", simple_listener)
    event_bus.subscribe("DATA_PROCESSED", another_listener)

    print("\n--- Publication d'événements synchrones --- ")
    event_bus.publish("USER_LOGIN", message="Utilisateur John Doe connecté", source="AuthModule")
    event_bus.publish("DATA_PROCESSED", data={"id": 123, "value": 42, "status": "ok"})
    event_bus.publish("DATA_PROCESSED", data={"id": 456, "value": -1, "status": "error"}) # Va lever une exception
    event_bus.publish("EVENT_SANS_LISTENER", message="Ce message ne sera pas vu par un listener spécifique.")

    event_bus.unsubscribe("USER_LOGIN", simple_listener)
    print("\n--- Publication après désabonnement de simple_listener --- ")
    event_bus.publish("USER_LOGIN", message="Utilisateur Jane Doe connectée") # Ne devrait plus appeler simple_listener

    # Listeners asynchrones
    async def async_price_updater(symbol: str, price: float):
        print(f"[Async Price Updater] Mise à jour du prix pour {symbol}: {price:.2f}. Attente de 0.1s...")
        await asyncio.sleep(0.1)
        print(f"[Async Price Updater] {symbol} @ {price:.2f} - Traitement terminé.")
        if symbol == "FAIL":
            raise RuntimeError("Erreur forcée dans async_price_updater pour FAIL")

    async def async_notification_sender(user_id: int, notification: str):
        print(f"[Async Notification Sender] Envoi de la notification à l'utilisateur {user_id}: '{notification}'. Attente de 0.2s...")
        await asyncio.sleep(0.2)
        print(f"[Async Notification Sender] Notification envoyée à {user_id}.")

    event_bus.subscribe_async("NEW_TRADE_DATA", async_price_updater)
    event_bus.subscribe_async("USER_ALERT", async_notification_sender)
    event_bus.subscribe_async("NEW_TRADE_DATA", async_notification_sender) # Un même listener peut s'abonner à plusieurs événements si pertinent
                                                                        # ou un même événement peut avoir plusieurs listeners async

    async def main_async_test():
        print("\n--- Publication d'événements asynchrones --- ")
        await event_bus.publish_async("NEW_TRADE_DATA", symbol="BTC/USD", price=60000.50)
        await event_bus.publish_async("USER_ALERT", user_id=101, notification="Maintenance prévue ce soir.")
        await event_bus.publish_async("NEW_TRADE_DATA", symbol="ETH/USD", price=4000.75)
        await event_bus.publish_async("NEW_TRADE_DATA", symbol="FAIL", price=0.00) # Va lever une exception
        
        # Test de désabonnement async
        event_bus.unsubscribe_async("NEW_TRADE_DATA", async_price_updater)
        print("\n--- Publication après désabonnement de async_price_updater de NEW_TRADE_DATA --- ")
        await event_bus.publish_async("NEW_TRADE_DATA", symbol="ADA/USD", price=2.50) # async_notification_sender devrait toujours être appelé

    asyncio.run(main_async_test())

    print("\nFin de l'exemple EventBus.")

