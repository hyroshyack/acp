# src/acp768/core/config_loader.py
import configparser
import os
from typing import Dict, Any, Optional

class ConfigLoader:
    """Charge et gère la configuration de l'application à partir de fichiers INI."""

    def __init__(self, default_config_path: str, user_config_path: Optional[str] = None, env_prefix: str = "ACP768_"):
        """
        Initialise le ConfigLoader.

        Args:
            default_config_path: Chemin vers le fichier de configuration par défaut.
            user_config_path: Chemin optionnel vers le fichier de configuration utilisateur (surcharge le défaut).
            env_prefix: Préfixe pour les variables d'environnement qui peuvent surcharger la configuration.
        """
        self.config = configparser.ConfigParser()
        self.env_prefix = env_prefix

        if not os.path.exists(default_config_path):
            raise FileNotFoundError(f"Le fichier de configuration par défaut est introuvable : {default_config_path}")
        self.config.read(default_config_path)

        if user_config_path and os.path.exists(user_config_path):
            self.config.read(user_config_path)
        elif user_config_path:
            print(f"Avertissement : Le fichier de configuration utilisateur spécifié n'a pas été trouvé : {user_config_path}")

        self._override_with_env_vars()

    def _override_with_env_vars(self):
        """Surcharge les valeurs de configuration avec des variables d'environnement."""
        for section in self.config.sections():
            for key in self.config[section]:
                env_var_name = f"{self.env_prefix}{section.upper()}_{key.upper()}"
                env_value = os.getenv(env_var_name)
                if env_value is not None:
                    self.config[section][key] = env_value
                    print(f"Configuration surchargée par la variable d'environnement {env_var_name}")

    def get(self, section: str, key: str, fallback: Any = None) -> Optional[str]:
        """Récupère une valeur de configuration de type string."""
        return self.config.get(section, key, fallback=fallback)

    def get_int(self, section: str, key: str, fallback: Any = None) -> Optional[int]:
        """Récupère une valeur de configuration de type integer."""
        try:
            return self.config.getint(section, key, fallback=fallback)
        except (ValueError, configparser.NoOptionError, configparser.NoSectionError) as e:
            if fallback is not None:
                return fallback
            print(f"Erreur lors de la récupération de l'entier {section}.{key}: {e}")
            return None

    def get_float(self, section: str, key: str, fallback: Any = None) -> Optional[float]:
        """Récupère une valeur de configuration de type float."""
        try:
            return self.config.getfloat(section, key, fallback=fallback)
        except (ValueError, configparser.NoOptionError, configparser.NoSectionError) as e:
            if fallback is not None:
                return fallback
            print(f"Erreur lors de la récupération du flottant {section}.{key}: {e}")
            return None

    def get_boolean(self, section: str, key: str, fallback: Any = None) -> Optional[bool]:
        """Récupère une valeur de configuration de type boolean."""
        try:
            return self.config.getboolean(section, key, fallback=fallback)
        except (ValueError, configparser.NoOptionError, configparser.NoSectionError) as e:
            if fallback is not None:
                return fallback
            print(f"Erreur lors de la récupération du booléen {section}.{key}: {e}")
            return None

    def get_section(self, section: str) -> Optional[Dict[str, str]]:
        """Récupère une section entière de la configuration sous forme de dictionnaire."""
        if self.config.has_section(section):
            return dict(self.config[section])
        return None

# Exemple d'utilisation (sera typiquement dans src/acp768/core/__init__.py ou main.py)
if __name__ == '__main__':
    # Créer des fichiers de configuration factices pour le test
    default_config_content = """
[General]
app_name = ACP768
debug_mode = true

[API_Keys]
infura_api_key = YOUR_DEFAULT_INFURA_KEY_HERE

[Node_Erigon]
host = localhost
port = 8545
    """
    user_config_content = """
[API_Keys]
infura_api_key = MY_ACTUAL_USER_KEY

[Node_Erigon]
port = 8555
    """

    with open("/home/ubuntu/acp768_project/config/default_config.ini", "w") as f:
        f.write(default_config_content)
    with open("/home/ubuntu/acp768_project/config/user_config.ini", "w") as f:
        f.write(user_config_content)

    # Simuler une variable d'environnement
    os.environ['ACP768_GENERAL_DEBUG_MODE'] = 'false'

    config_loader = ConfigLoader(
        default_config_path="/home/ubuntu/acp768_project/config/default_config.ini",
        user_config_path="/home/ubuntu/acp768_project/config/user_config.ini"
    )

    print(f"Nom de l'application: {config_loader.get('General', 'app_name')}")
    print(f"Mode Debug (attendu: False car surchargé par env): {config_loader.get_boolean('General', 'debug_mode')}")
    print(f"Clé API Infura (attendue: MY_ACTUAL_USER_KEY car surchargé par user_config): {config_loader.get('API_Keys', 'infura_api_key')}")
    print(f"Port Erigon (attendu: 8555 car surchargé par user_config): {config_loader.get_int('Node_Erigon', 'port')}")
    print(f"Hôte Erigon: {config_loader.get('Node_Erigon', 'host')}")
    print(f"Section API_Keys: {config_loader.get_section('API_Keys')}")
    print(f"Option inexistante avec fallback: {config_loader.get('General', 'version', fallback='1.0.0')}")
    print(f"Option inexistante sans fallback: {config_loader.get('General', 'non_existent_key')}")

    # Nettoyer la variable d'environnement simulée
    del os.environ['ACP768_GENERAL_DEBUG_MODE']

