# src/acp768/user_interface/vr_ui/__init__.py
"""Module pour l_interface utilisateur VR 3D de l_application ACP768."""

from .vr_app_launcher import VRAppLauncher

__all__ = ["VRAppLauncher"]

