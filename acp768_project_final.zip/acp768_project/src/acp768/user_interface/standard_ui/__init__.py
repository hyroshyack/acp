# src/acp768/user_interface/standard_ui/__init__.py
"""Module pour l_interface utilisateur standard de l_application ACP768."""

from .main_window import StandardMainWindow

__all__ = ["StandardMainWindow"]

