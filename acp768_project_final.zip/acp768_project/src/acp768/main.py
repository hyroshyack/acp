# src/acp768/main.py
import asyncio
import logging
import os
import signal
from typing import Optional

from acp768.core.config_loader import ConfigLoader
from acp768.core.event_bus import EventBus
from acp768.core.logging_setup import setup_logging

from acp768.data_management.data_manager import DataManager
from acp768.blockchain_integration.api_handler import APIHandler
from acp768.trading_engine.arbitrage_manager import ArbitrageManager
from acp768.trading_engine.strategy_executor import StrategyExecutor
from acp768.trading_engine.risk_manager import RiskManager
from acp768.trading_engine.portfolio_optimizer import PortfolioOptimizer
from acp768.trading_engine.flashloan_handler import FlashloanHandler
from acp768.ai_ml_components.ml_predictor import MLPredictor
from acp768.ai_ml_components.sentiment_analyzer import SentimentAnalyzer
from acp768.security.security_manager import SecurityManager
from acp768.user_interface.ui_manager import UIManager
# Import UI implementations if they need to be explicitly managed here (e.g. for PyQt app.exec_())
# from acp768.user_interface.standard_ui.main_window import StandardMainWindow

# Get the root directory of the project (ACP768_Project)
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
# print(f"Project Root: {PROJECT_ROOT}")

DEFAULT_CONFIG_PATH = os.path.join(PROJECT_ROOT, "config", "main_config.ini")
LOG_DIR = os.path.join(PROJECT_ROOT, "logs", "application")

logger = logging.getLogger("acp768.main")

class Application:
    """Classe principale de l_application ACP768."""

    def __init__(self, config_path: Optional[str] = None):
        self.config_loader: Optional[ConfigLoader] = None
        self.event_bus: Optional[EventBus] = None
        self.data_manager: Optional[DataManager] = None
        self.api_handler: Optional[APIHandler] = None
        self.security_manager: Optional[SecurityManager] = None
        self.arbitrage_manager: Optional[ArbitrageManager] = None
        self.strategy_executor: Optional[StrategyExecutor] = None
        self.risk_manager: Optional[RiskManager] = None
        self.portfolio_optimizer: Optional[PortfolioOptimizer] = None
        self.flashloan_handler: Optional[FlashloanHandler] = None
        self.ml_predictor: Optional[MLPredictor] = None
        self.sentiment_analyzer: Optional[SentimentAnalyzer] = None
        self.ui_manager: Optional[UIManager] = None
        
        self._running_tasks = []
        self._config_path = config_path or DEFAULT_CONFIG_PATH

    async def initialize(self):
        """Initialise tous les composants de l_application."""
        try:
            # 0. Configuration du Logging (le plus tôt possible)
            os.makedirs(LOG_DIR, exist_ok=True)
            # Le setup_logging est appelé globalement, mais on peut le réaffirmer ici si besoin
            # setup_logging(log_dir=LOG_DIR) # Déjà fait au niveau du module logging_setup ?
            logger.info(f"Initialisation de l_application ACP768 depuis {self._config_path}")

            # 1. Chargeur de Configuration
            self.config_loader = ConfigLoader(default_config_path=self._config_path)
            app_name = self.config_loader.get("Application", "name", fallback="ACP768")
            app_version = self.config_loader.get("Application", "version", fallback="1.0.0-refactored")
            logger.info(f"Chargement de la configuration pour {app_name} v{app_version}")

            # 2. Bus d_Événements
            self.event_bus = EventBus()
            logger.info("Bus d_événements initialisé.")

            # 3. Gestionnaire de Sécurité (tôt pour les autres modules)
            self.security_manager = SecurityManager(self.config_loader, self.event_bus)
            logger.info("Gestionnaire de sécurité initialisé.")

            # 4. Gestionnaire de Données
            self.data_manager = DataManager(self.config_loader, self.event_bus)
            await self.data_manager.connect_all() # Connexion aux bases de données
            logger.info("Gestionnaire de données initialisé et connecté.")

            # 5. Gestionnaire d_API Blockchain
            self.api_handler = APIHandler(self.config_loader, self.event_bus)
            # La connexion se fera à la demande ou au démarrage des services qui l_utilisent
            logger.info("Gestionnaire d_API Blockchain initialisé.")

            # 6. Modules du Moteur de Trading
            self.strategy_executor = StrategyExecutor(self.config_loader, self.data_manager, self.api_handler, self.event_bus)
            logger.info("Exécuteur de stratégie initialisé.")
            self.risk_manager = RiskManager(self.config_loader, self.data_manager, self.api_handler, self.event_bus)
            logger.info("Gestionnaire de risques initialisé.")
            self.portfolio_optimizer = PortfolioOptimizer(self.config_loader, self.data_manager, self.event_bus)
            logger.info("Optimiseur de portefeuille initialisé.")
            self.flashloan_handler = FlashloanHandler(self.config_loader, self.api_handler, self.event_bus)
            logger.info("Gestionnaire de Flashloan initialisé.")
            self.arbitrage_manager = ArbitrageManager(self.config_loader, self.data_manager, self.api_handler, self.event_bus)
            logger.info("Gestionnaire d_arbitrage initialisé.")

            # 7. Composants IA/ML
            self.ml_predictor = MLPredictor(self.config_loader, self.data_manager, self.event_bus)
            logger.info("Prédicteur ML initialisé.")
            self.sentiment_analyzer = SentimentAnalyzer(self.config_loader, self.event_bus)
            logger.info("Analyseur de sentiment initialisé.")

            # 8. Gestionnaire d_Interface Utilisateur
            # L_UIManager aura besoin de certaines dépendances pour les UI spécifiques
            self.ui_manager = UIManager(
                config_loader=self.config_loader, 
                event_bus=self.event_bus
                # Passez d_autres gestionnaires ici si les UI en ont besoin directement
                # data_manager=self.data_manager,
                # api_handler=self.api_handler 
            )
            logger.info("Gestionnaire d_interface utilisateur initialisé.")

            logger.info("Initialisation de l_application ACP768 terminée avec succès.")
            if self.event_bus:
                await self.event_bus.publish_async("APPLICATION_INITIALIZED", app_name=app_name, version=app_version)
            return True

        except Exception as e:
            logger.critical(f"Erreur critique lors de l_initialisation de l_application: {e}", exc_info=True)
            # Tenter un arrêt propre même en cas d_échec d_initialisation
            await self.shutdown(graceful=False)
            return False

    async def start_services(self):
        """Démarre les services de fond de l_application."""
        if not self.config_loader or not self.arbitrage_manager or not self.risk_manager:
            logger.error("Application non initialisée correctement. Impossible de démarrer les services.")
            return

        logger.info("Démarrage des services de l_application...")
        
        # Démarrer la surveillance des arbitrages si activée dans la config
        if self.config_loader.get_boolean("ArbitrageSettings", "start_monitoring_on_boot", fallback=True):
            await self.arbitrage_manager.start_monitoring()
            # self._running_tasks.append(self.arbitrage_manager._monitoring_task) # Pas directement, gérer via stop

        # Démarrer la surveillance des risques si activée
        if self.config_loader.get_boolean("RiskManagementSettings", "start_monitoring_on_boot", fallback=True):
            await self.risk_manager.start_risk_monitoring()

        # D_autres services de fond pourraient être démarrés ici
        logger.info("Services de l_application démarrés.")
        if self.event_bus:
            await self.event_bus.publish_async("APPLICATION_SERVICES_STARTED")

    async def run(self):
        """Lance l_application et son interface utilisateur principale."""
        if not await self.initialize():
            logger.error("Échec de l_initialisation de l_application. Arrêt.")
            return

        await self.start_services()

        # Lancer l_UI par défaut
        if self.ui_manager:
            # La méthode initialize_ui de UIManager devrait lancer l_UI par défaut (standard)
            # et potentiellement bloquer si c_est une application de bureau (ex: PyQt)
            # ou retourner immédiatement si c_est une UI non bloquante (ex: serveur web pour WebXR)
            logger.info("Lancement de l_interface utilisateur par défaut...")
            ui_launched_successfully = await self.ui_manager.initialize_ui()
            if not ui_launched_successfully:
                logger.error("Impossible de lancer l_interface utilisateur principale. L_application pourrait ne pas être utilisable.")
                # Selon la criticité de l_UI, on pourrait décider d_arrêter l_application ici.
                # await self.shutdown()
                # return
        else:
            logger.error("UIManager non initialisé. Impossible de lancer l_interface utilisateur.")
            await self.shutdown()
            return

        # Boucle principale de l_application (si l_UI n_est pas bloquante)
        # Si l_UI est bloquante (comme une app PyQt avec app.exec_()), cette boucle ne sera pas atteinte
        # tant que l_UI est active. La gestion de l_arrêt se ferait via des signaux de l_UI.
        # Pour un service purement backend ou une UI non bloquante, cette boucle est pertinente.
        try:
            while True: # Maintenir l_application en vie
                # Ici, on pourrait écouter des signaux d_arrêt ou d_autres événements globaux
                # si l_UI n_est pas la principale source de contrôle de la durée de vie.
                if self.ui_manager and not self.ui_manager.current_ui_mode:
                    logger.info("L_interface utilisateur principale semble s_être fermée. Préparation de l_arrêt.")
                    break # Sortir de la boucle si l_UI est fermée et qu_elle était la principale
                await asyncio.sleep(1) 
        except (KeyboardInterrupt, SystemExit):
            logger.info("Signal d_arrêt reçu (KeyboardInterrupt/SystemExit).")
        finally:
            logger.info("Arrêt de la boucle principale de l_application.")
            await self.shutdown()

    async def shutdown(self, graceful=True):
        """Arrête proprement tous les composants de l_application."""
        logger.info(f"Arrêt de l_application ACP768 ({'graceful' if graceful else 'forced'})...")

        # 1. Arrêter les services de fond
        if self.arbitrage_manager and self.arbitrage_manager.is_running:
            logger.info("Arrêt du gestionnaire d_arbitrage...")
            await self.arbitrage_manager.stop_monitoring()
        if self.risk_manager and self.risk_manager.is_monitoring:
            logger.info("Arrêt du gestionnaire de risques...")
            await self.risk_manager.stop_risk_monitoring()
        
        # Annuler d_autres tâches de fond si elles ont été explicitement suivies
        for task in self._running_tasks:
            if task and not task.done():
                task.cancel()
        if self._running_tasks:
            await asyncio.gather(*[t for t in self._running_tasks if t], return_exceptions=True)
            logger.info("Tâches de fond annulées.")

        # 2. Fermer l_interface utilisateur
        if self.ui_manager and self.ui_manager.current_ui_mode:
            logger.info(f"Fermeture de l_interface utilisateur ({self.ui_manager.current_ui_mode})...")
            await self.ui_manager.close_ui()

        # 3. Déconnecter les gestionnaires de ressources externes
        if self.api_handler:
            logger.info("Déconnexion du gestionnaire d_API Blockchain...")
            await self.api_handler.disconnect_all_nodes()
        if self.data_manager:
            logger.info("Déconnexion du gestionnaire de données...")
            await self.data_manager.disconnect_all()

        # 4. Publier un événement de fin
        if self.event_bus:
            logger.info("Publication de l_événement d_arrêt de l_application.")
            await self.event_bus.publish_async("APPLICATION_SHUTDOWN", graceful=graceful)
            # Potentiellement attendre un peu pour que les derniers événements soient traités
            await asyncio.sleep(0.1)

        logger.info("Arrêt de l_application ACP768 terminé.")

async def main():
    # Configuration initiale du logging (avant même ConfigLoader pour les logs de ConfigLoader lui-même)
    setup_logging(log_dir=LOG_DIR, console_level=logging.INFO, file_level=logging.DEBUG)
    
    app = Application()

    # Gestion des signaux d_arrêt pour un arrêt propre
    loop = asyncio.get_event_loop()
    stop_event = asyncio.Event()

    def signal_handler():
        logger.info("Signal d_arrêt système reçu. Démarrage de l_arrêt propre.")
        if not stop_event.is_set():
            stop_event.set()
            # Lancer l_arrêt dans la boucle d_événements pour éviter les problèmes de thread
            loop.create_task(app.shutdown())

    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, signal_handler)
        except NotImplementedError:
            # add_signal_handler n_est pas supporté sur toutes les plateformes (ex: Windows pour SIGTERM parfois)
            logger.warning(f"Impossible d_enregistrer le gestionnaire de signal pour {sig}. L_arrêt propre via signal pourrait ne pas fonctionner.")

    try:
        await app.run()
    except Exception as e:
        logger.critical(f"Une erreur non gérée s_est produite au niveau supérieur de l_application: {e}", exc_info=True)
        # Tenter un arrêt d_urgence
        await app.shutdown(graceful=False)
    finally:
        # S_assurer que les gestionnaires de signaux sont retirés pour éviter les erreurs lors de la fermeture de la boucle
        for sig in (signal.SIGINT, signal.SIGTERM):
            try:
                loop.remove_signal_handler(sig)
            except Exception:
                pass # Ignorer les erreurs ici, on est en train de fermer
        logger.info("Application terminée.")

if __name__ == "__main__":
    # Créer un fichier de configuration par défaut s_il n_existe pas
    if not os.path.exists(DEFAULT_CONFIG_PATH):
        os.makedirs(os.path.dirname(DEFAULT_CONFIG_PATH), exist_ok=True)
        default_config_content = """
[Application]
name = ACP768
version = 1.0.0-refactored

[Logging]
log_level_console = INFO
log_level_file = DEBUG
log_file_name = acp768_app.log
log_max_bytes = 10485760 # 10MB
log_backup_count = 5

[UISettings]
default_ui_mode = standard # 'standard' or 'vr'
enable_vr_mode = true

[VRSettings]
default_environment_scene = trading_deck_v1
render_quality = high

[BlockchainNodes]
# Configurez vos nœuds ici (voir api_handler.py pour des exemples)
# Exemple: (décommentez et adaptez si vous avez un nœud local ou un ID Infura)
# node_priority_order = erigon_local, infura_sepolia
# erigon_local = erigon
# erigon_local_enabled = false 
# erigon_local_url = http://localhost:8545
# infura_sepolia = infura
# infura_sepolia_enabled = false
# infura_sepolia_url = wss://sepolia.infura.io/ws/v3/YOUR_INFURA_PROJECT_ID
# infura_sepolia_project_id = YOUR_INFURA_PROJECT_ID
# infura_sepolia_network = sepolia
default_request_timeout = 30

[Databases]
# Configurez vos bases de données ici (voir data_manager.py pour des exemples)
sqlite_main_enabled = true
sqlite_main_default = true

[DB_SQLITE_MAIN]
db_path = ${ACP768_PROJECT_ROOT}/data/acp768_main.db
# ${ACP768_PROJECT_ROOT} sera remplacé par le chemin racine du projet.

[ArbitrageSettings]
start_monitoring_on_boot = true
monitoring_interval_seconds = 60
min_profit_threshold_usd = 1.0

[RiskManagementSettings]
start_monitoring_on_boot = true
risk_monitoring_interval_seconds = 300
max_total_usd_exposure = 100000.0
max_single_asset_usd_exposure = 25000.0
max_loss_percent_per_trade = 2.0
max_daily_drawdown_percent = 5.0

[StrategyExecutorSettings]
max_gas_price_gwei = 100
slippage_tolerance_percent = 0.5
default_gas_limit = 500000
# trader_wallet_address = VOTRE_ADRESSE_DE_PORTEFEUILLE_POUR_LE_TRADING (à gérer de manière sécurisée)

[FlashloanSettings]
# default_provider_address = ADRESSE_DU_FOURNISSEUR_DE_FLASHLOAN (ex: Aave LendingPool)
max_flashloan_fee_percent = 0.09
gas_limit_multiplier_for_flashloan_tx = 1.5

[PortfolioOptimizerSettings]
optimization_frequency_hours = 24
default_optimization_strategy = maximize_sharpe_ratio

[MLPredictorSettings]
default_model_directory_path = ${ACP768_PROJECT_ROOT}/models/ml_predictor/
price_prediction_model_filename = price_predictor_v1.joblib

[SentimentAnalyzerSettings]
default_sentiment_model = vader
# nltk_data_path = /opt/nltk_data # Optionnel

[SecuritySettings]
api_key_rotation_policy_days = 90
enable_2fa_for_critical_ops = false
# Pour le KeyManager (non implémenté ici), vous auriez des configurations pour le keystore, etc.
# keystore_path = ${ACP768_PROJECT_ROOT}/secure/keystore.json
# master_password_env_var = ACP768_MASTER_PASSWORD
        """
        # Remplacer ${ACP768_PROJECT_ROOT} par le chemin réel
        # Note: ConfigLoader gère déjà la variable d_environnement ACP768_PROJECT_ROOT si elle est définie.
        # Ici, nous le faisons explicitement pour le fichier de configuration par défaut.
        processed_config_content = default_config_content.replace("${ACP768_PROJECT_ROOT}", PROJECT_ROOT.replace("\\", "/"))
        with open(DEFAULT_CONFIG_PATH, "w") as f:
            f.write(processed_config_content)
        logger.info(f"Fichier de configuration par défaut créé à: {DEFAULT_CONFIG_PATH}")
        # Créer les répertoires de données et de modèles par défaut s_ils n_existent pas
        os.makedirs(os.path.join(PROJECT_ROOT, "data"), exist_ok=True)
        os.makedirs(os.path.join(PROJECT_ROOT, "models", "ml_predictor"), exist_ok=True)
        os.makedirs(os.path.join(PROJECT_ROOT, "secure"), exist_ok=True) # Pour un futur keystore

    asyncio.run(main())

