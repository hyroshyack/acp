# Projet ACP768 - Application d_Arbitrage et de Trading Crypto

## Version

1.0.0-refactored

## Introduction

ACP768 est une application Python modulaire conçue pour l_analyse des marchés de cryptomonnaies, la détection d_opportunités d_arbitrage, l_exécution de stratégies de trading, et la gestion de portefeuille. Elle est dotée d_une architecture flexible permettant l_intégration de divers services de données, d_API blockchain, de modèles d_intelligence artificielle, et offre des interfaces utilisateur standard et VR (simulée).

Ce document README fournit un aperçu général du projet, de sa structure, de sa configuration et de son lancement.

## Structure du Projet

Le projet est organisé de manière modulaire pour faciliter la maintenance, l_évolutivité et les tests. Les principaux composants se trouvent dans le répertoire `src/acp768`:

-   **`core/`**: Contient les composants de base de l_application :
    -   `config_loader.py`: Gestion du chargement des configurations.
    -   `event_bus.py`: Système de messagerie interne pour la communication entre modules.
    -   `logging_setup.py`: Configuration centralisée du logging.
-   **`data_management/`**: Responsable de l_interaction avec les bases de données et autres sources de données.
    -   `data_manager.py`: Orchestrateur principal pour les opérations de données.
    -   `connectors/`: Modules pour se connecter à différents types de bases de données (ex: SQLite).
-   **`blockchain_integration/`**: Gère la communication avec les nœuds blockchain (ex: Ethereum).
    -   `api_handler.py`: Point central pour interagir avec les API des nœuds.
    -   `node_interface.py`: Interface abstraite pour les différents types de nœuds.
    -   `erigon_node.py`, `infura_node.py`: Implémentations spécifiques pour les nœuds Erigon et Infura.
-   **`trading_engine/`**: Contient la logique de trading, d_arbitrage et de gestion des risques.
    -   `arbitrage_manager.py`: Détection des opportunités d_arbitrage.
    -   `strategy_executor.py`: Exécution des transactions et des stratégies.
    -   `risk_manager.py`: Surveillance et gestion des risques.
    -   `portfolio_optimizer.py`: Optimisation de la composition du portefeuille.
    -   `flashloan_handler.py`: Gestion des opérations de flash loan (simulée).
-   **`ai_ml_components/`**: Modules pour l_intégration de l_intelligence artificielle et du machine learning.
    -   `ml_predictor.py`: Prédiction de prix ou d_autres indicateurs (simulée).
    -   `sentiment_analyzer.py`: Analyse de sentiment à partir de textes (simulée).
-   **`security/`**: Composants liés à la sécurité de l_application.
    -   `security_manager.py`: Orchestrateur des fonctions de sécurité (gestion des clés API simulée, logging d_audit).
-   **`user_interface/`**: Gestion des interfaces utilisateur.
    -   `ui_manager.py`: Permet de basculer entre les modes d_interface (standard, VR).
    -   `standard_ui/`: Implémentation de l_interface utilisateur de bureau standard (simulée).
    -   `vr_ui/`: Implémentation de l_interface utilisateur VR (simulée).
-   **`main.py`**: Point d_entrée principal de l_application, initialise et orchestre tous les modules.
-   **`__init__.py`**: Marque le répertoire `acp768` comme un package Python.

Autres répertoires importants à la racine du projet (`acp768_project`):

-   **`config/`**: Contient les fichiers de configuration (ex: `main_config.ini`).
-   **`data/`**: Utilisé pour stocker les bases de données locales (ex: fichiers SQLite).
-   **`logs/`**: Contient les fichiers journaux de l_application.
    -   `application/`: Logs du `main.py` et des modules principaux.
    -   `logs_test_*/`: Logs spécifiques générés par les exemples de chaque module (si exécutés individuellement).
-   **`models/`**: Destiné à stocker les modèles de machine learning pré-entraînés.
-   **`secure/`**: Prévu pour les données sensibles comme les keystores (actuellement non utilisé en profondeur).
-   **`docs/`**: Devrait contenir la documentation détaillée, y compris ce README, le tutoriel, et les rapports générés.

## Configuration

La configuration principale de l_application se trouve dans `config/main_config.ini`. Ce fichier est créé automatiquement avec des valeurs par défaut lors du premier lancement si `main.py` est exécuté et qu_il n_existe pas.

### Variables d_Environnement Clés

-   **`ACP768_PROJECT_ROOT`**: (Optionnel) Peut être défini pour pointer vers le répertoire racine du projet (`acp768_project`). Si non défini, le `ConfigLoader` et `main.py` tentent de le déduire. Le `main_config.ini` par défaut utilise `${ACP768_PROJECT_ROOT}` qui sera substitué.
-   **`INFURA_PROJECT_ID`**: Nécessaire si vous utilisez Infura comme nœud Ethereum. À remplacer par votre propre ID de projet Infura dans `main_config.ini`.
-   **`TRADER_WALLET_ADDRESS`**: L_adresse de votre portefeuille Ethereum à utiliser pour le trading. Doit être configurée dans `main_config.ini` sous `[StrategyExecutorSettings]`. **La gestion des clés privées associées n_est pas implémentée de manière sécurisée dans cette version simulée ; soyez extrêmement prudent si vous adaptez ce code pour une utilisation réelle.**
-   **`ACP768_APP_MODE`**: (Introduit pour la commutabilité) Peut être défini à `simulation` ou `production`. Par défaut, si non défini, l_application pourrait se comporter comme en mode `production` ou selon les configurations spécifiques des modules. Voir la section "Commutabilité" ci-dessous.

### Sections de Configuration Principales (`main_config.ini`)

-   **`[Application]`**: Nom et version de l_application.
-   **`[Logging]`**: Niveaux de log pour la console et les fichiers, nom du fichier log, politique de rotation.
-   **`[UISettings]`**: Mode UI par défaut (`standard` ou `vr`), activation du mode VR.
-   **`[VRSettings]`**: Paramètres spécifiques à l_environnement VR (scène par défaut, qualité de rendu).
-   **`[BlockchainNodes]`**: Configuration des points de connexion aux nœuds Ethereum (Erigon local, Infura, etc.). Inclut les URLs, l_état activé/désactivé, les ID de projet pour Infura, et l_ordre de priorité.
-   **`[Databases]`**: Configuration des bases de données (ex: SQLite, avec chemin vers le fichier de base de données).
-   **`[ArbitrageSettings]`**: Paramètres pour le gestionnaire d_arbitrage (intervalle de surveillance, seuil de profit minimum, démarrage automatique).
-   **`[RiskManagementSettings]`**: Paramètres pour la gestion des risques (intervalle de surveillance, limites d_exposition, drawdown maximum).
-   **`[StrategyExecutorSettings]`**: Paramètres pour l_exécution des stratégies (prix maximum du gaz, tolérance au slippage, adresse du portefeuille trader).
-   **`[FlashloanSettings]`**: Configuration pour les opérations de flash loan (fournisseur par défaut, frais maximum).
-   **`[PortfolioOptimizerSettings]`**: Paramètres pour l_optimisation de portefeuille (fréquence, stratégie par défaut).
-   **`[MLPredictorSettings]`**: Chemin vers les modèles ML, noms des fichiers de modèles.
-   **`[SentimentAnalyzerSettings]`**: Modèle d_analyse de sentiment à utiliser (ex: VADER).
-   **`[SecuritySettings]`**: Politiques de sécurité (rotation des clés API simulée, activation 2FA simulée).

## Commutabilité (Mode Simulation vs. Production)

L_application est conçue pour permettre une certaine flexibilité entre un mode de simulation et un mode de production. Ceci est crucial pour tester les stratégies sans risquer des fonds réels.

1.  **Variable d_Environnement `ACP768_APP_MODE`**:
    Définissez cette variable d_environnement avant de lancer l_application :
    -   `export ACP768_APP_MODE=simulation`
    -   `export ACP768_APP_MODE=production`
    Le `ConfigLoader` peut lire cette variable et l_utiliser pour sélectionner des configurations spécifiques si elles sont définies (par exemple, `[BlockchainNodes_simulation]` vs `[BlockchainNodes_production]`). Cette fonctionnalité est conceptuelle dans la version actuelle du `ConfigLoader` et nécessiterait une implémentation plus poussée pour charger dynamiquement des sections alternatives.

2.  **Configuration Spécifique aux Modules**:
    -   **`APIHandler`**: En mode `simulation`, vous devriez configurer `[BlockchainNodes]` pour pointer vers des testnets (ex: Sepolia via Infura) ou des nœuds locaux avec des données de test. En mode `production`, vous pointeriez vers le mainnet Ethereum.
    -   **`StrategyExecutor`**: En mode `simulation`, les appels d_envoi de transactions (`send_raw_transaction`) devraient être interceptés ou dirigés vers un environnement de test où aucune valeur réelle n_est échangée. Le module actuel simule principalement ces étapes.
    -   **`DataManager`**: Pourrait se connecter à des bases de données de test en mode `simulation`.

3.  **Clés API et Portefeuilles**:
    -   Utilisez des clés API distinctes pour les environnements de test et de production.
    -   Utilisez des adresses de portefeuille de test avec des fonds de test en mode `simulation`.

**Recommandation Actuelle**: La version actuelle des scripts est principalement une simulation élaborée. Pour passer en production réelle, une validation de sécurité exhaustive, une gestion sécurisée des clés privées (non incluse ici), et des tests approfondis sur les testnets sont impératifs. La logique de commutation de mode doit être renforcée dans chaque module critique.

## Installation des Dépendances

Un fichier `requirements.txt` sera fourni pour installer les dépendances Python nécessaires. Les dépendances principales anticipées incluent (mais ne sont pas limitées à) :

-   `web3` (pour l_interaction Ethereum)
-   `aiohttp` (pour les requêtes HTTP asynchrones, utilisé par `web3`)
-   `aiosqlite` (pour la base de données SQLite asynchrone)
-   Optionnellement, pour l_UI standard : `PyQt6` ou `Tkinter` (non inclus par défaut dans `requirements.txt` si l_UI est purement simulée dans le code fourni).
-   Optionnellement, pour les composants ML/AI : `scikit-learn`, `joblib`, `nltk`, `torch`, `transformers` (ces dépendances peuvent être lourdes et ne sont nécessaires que si les fonctionnalités ML/AI sont activement développées au-delà de la simulation actuelle).

Pour installer les dépendances de base (une fois `requirements.txt` généré) :

```bash
pip3 install -r requirements.txt
```

## Lancement de l_Application

Pour lancer l_application, exécutez le script `main.py` depuis le répertoire `src/acp768/` ou le répertoire racine du projet.

```bash
cd /chemin/vers/acp768_project
python3 src/acp768/main.py
```

L_application démarrera, initialisera tous les modules configurés, et lancera l_interface utilisateur par défaut (généralement l_interface standard).

### Lancement en Mode Spécifique

Pour influencer le mode (simulation/production), assurez-vous que la variable d_environnement `ACP768_APP_MODE` est définie et que votre `main_config.ini` reflète les paramètres appropriés pour ce mode.

## Documentation Utilisateur et Tutoriel

-   **`TUTORIAL.md`**: Un guide pas à pas pour configurer l_application, comprendre ses fonctionnalités principales, et l_utiliser.
-   **Rapports d_Analyse (précédemment générés)**: Ces documents (`rapport_etat_actuel_acp768_complet.md`, etc.) fournissent le contexte de la refonte et les objectifs de conception.

## Contributions et Développement Futur

Ce projet est une base. Les domaines d_amélioration futurs incluent :

-   Implémentation complète et sécurisée de la gestion des clés privées.
-   Développement complet des interfaces utilisateur Standard et VR (au-delà de la simulation).
-   Intégration de modèles ML/AI plus sophistiqués et entraînés.
-   Support pour d_autres blockchains et exchanges.
-   Tests unitaires et d_intégration exhaustifs.
-   Mécanismes de déploiement robustes.

## Licence

(À définir - par exemple, MIT, Apache 2.0, etc.)

