# Tutoriel d_Utilisation ACP768

## Introduction

Bienvenue dans le tutoriel d_utilisation de l_application ACP768. Ce guide vous aidera à configurer, lancer et utiliser les fonctionnalités principales de l_application.

ACP768 est une plateforme modulaire pour l_analyse des marchés de cryptomonnaies, la détection d_opportunités d_arbitrage, l_exécution de stratégies de trading et la gestion de portefeuille. Elle est conçue pour être flexible et extensible.

## Prérequis

Avant de commencer, assurez-vous d_avoir les éléments suivants :

1.  **Python 3.9+** installé sur votre système.
2.  **pip** (le gestionnaire de paquets Python) à jour.
3.  Un **accès à Internet** pour télécharger les dépendances et interagir avec les API blockchain.
4.  (Optionnel mais recommandé pour les tests) Un **ID de projet Infura** si vous souhaitez vous connecter au réseau Ethereum via Infura. Vous pouvez en obtenir un gratuitement sur [infura.io](https://infura.io).
5.  (Optionnel) Un **nœud Ethereum local** (comme Erigon ou Geth) si vous préférez ne pas utiliser Infura.
6.  (Optionnel pour le mode VR) Un **casque VR compatible** et le runtime correspondant (ex: SteamVR, Oculus) si vous souhaitez tester la fonctionnalité VR (actuellement simulée).

## 1. Installation

### 1.1. Récupération du Projet

Vous devriez avoir reçu une archive `.zip` du projet (par exemple, `acp768_project_final.zip`). Extrayez cette archive dans un répertoire de votre choix. Nous appellerons ce répertoire `ACP768_PROJECT_ROOT`.

```bash
# Exemple de commande si vous avez un fichier acp768_project_final.zip
unzip acp768_project_final.zip -d /chemin/vers/votre/espace_de_travail/
cd /chemin/vers/votre/espace_de_travail/acp768_project
export ACP768_PROJECT_ROOT=$(pwd)
```

### 1.2. Création d_un Environnement Virtuel (Recommandé)

Il est fortement recommandé d_utiliser un environnement virtuel Python pour isoler les dépendances du projet.

```bash
cd $ACP768_PROJECT_ROOT
python3 -m venv venv_acp768
source venv_acp768/bin/activate  # Sur Linux/macOS
# venv_acp768\Scripts\activate    # Sur Windows
```

### 1.3. Installation des Dépendances

Le projet inclut un fichier `requirements.txt` listant toutes les dépendances Python nécessaires.

```bash
cd $ACP768_PROJECT_ROOT
pip3 install -r requirements.txt
```

Cela installera des bibliothèques comme `web3`, `aiohttp`, `aiosqlite`, etc.

## 2. Configuration Initiale

L_application utilise un fichier de configuration principal `main_config.ini` situé dans le répertoire `$ACP768_PROJECT_ROOT/config/`.

Lors du premier lancement du script `src/acp768/main.py`, si ce fichier n_existe pas, il sera créé automatiquement avec des valeurs par défaut.

### 2.1. Configuration des Nœuds Blockchain

Ouvrez le fichier `$ACP768_PROJECT_ROOT/config/main_config.ini` avec un éditeur de texte.
Localisez la section `[BlockchainNodes]`.

-   **Pour utiliser Infura (recommandé pour commencer) :**
    1.  Assurez-vous d_avoir votre ID de projet Infura.
    2.  Modifiez les lignes suivantes (décommentez-les si nécessaire) :

        ```ini
        [BlockchainNodes]
        node_priority_order = infura_sepolia # Ou un autre nœud si vous préférez
        # ... autres configurations de nœuds ...
        infura_sepolia = infura
        infura_sepolia_enabled = true # Mettez à true pour l_activer
        infura_sepolia_url = wss://sepolia.infura.io/ws/v3/VOTRE_INFURA_PROJECT_ID
        infura_sepolia_project_id = VOTRE_INFURA_PROJECT_ID
        infura_sepolia_network = sepolia
        default_request_timeout = 30
        ```

        Remplacez `VOTRE_INFURA_PROJECT_ID` par votre ID de projet Infura réel.
        Le réseau `sepolia` est un testnet. Pour des opérations réelles (non recommandé sans audits de sécurité poussés et gestion de clés sécurisée), vous utiliseriez `mainnet`.

-   **Pour utiliser un nœud Erigon local :**
    1.  Assurez-vous que votre nœud Erigon est en cours d_exécution et synchronisé.
    2.  Modifiez/Décommentez :

        ```ini
        erigon_local = erigon
        erigon_local_enabled = true
        erigon_local_url = http://localhost:8545 # Ou l_URL de votre nœud
        ```

        Ajustez `node_priority_order` pour donner la priorité à `erigon_local` si vous le souhaitez.

### 2.2. Configuration de la Base de Données

Par défaut, l_application utilise une base de données SQLite qui sera créée dans le répertoire `$ACP768_PROJECT_ROOT/data/`.
La configuration se trouve dans la section `[Databases]` et `[DB_SQLITE_MAIN]`:

```ini
[Databases]
sqlite_main_enabled = true
sqlite_main_default = true

[DB_SQLITE_MAIN]
db_path = ${ACP768_PROJECT_ROOT}/data/acp768_main.db
```

La variable `${ACP768_PROJECT_ROOT}` sera automatiquement remplacée par le chemin absolu vers la racine de votre projet si la variable d_environnement `ACP768_PROJECT_ROOT` est définie, ou si le `ConfigLoader` peut le déduire.

### 2.3. Configuration du Portefeuille Trader (Important pour les fonctionnalités de trading)

Dans la section `[StrategyExecutorSettings]`, vous trouverez :

```ini
# trader_wallet_address = VOTRE_ADRESSE_DE_PORTEFEUILLE_POUR_LE_TRADING
```

Décommentez cette ligne et remplacez `VOTRE_ADRESSE_DE_PORTEFEUILLE_POUR_LE_TRADING` par l_adresse Ethereum que vous souhaitez utiliser pour les opérations de trading (même simulées).

**Avertissement de Sécurité Crucial** : La version actuelle de l_application **ne gère PAS de manière sécurisée les clés privées** associées à cette adresse. Toute opération de trading réelle nécessiterait une solution de gestion de clés robuste (ex: Hardware Wallet, Vault, etc.) qui n_est pas implémentée ici. Pour des tests, utilisez uniquement des adresses sur des testnets avec des fonds sans valeur réelle.

### 2.4. Autres Configurations

Passez en revue les autres sections du fichier `main_config.ini` (`[ArbitrageSettings]`, `[RiskManagementSettings]`, `[UISettings]`, etc.) pour ajuster les paramètres selon vos besoins. Les valeurs par défaut sont généralement conçues pour un premier test.

## 3. Lancement de l_Application

Une fois l_installation et la configuration terminées, vous pouvez lancer l_application.

Assurez-vous que votre environnement virtuel est activé.

```bash
cd $ACP768_PROJECT_ROOT
python3 src/acp768/main.py
```

L_application va :
1.  Initialiser le logging.
2.  Charger la configuration.
3.  Initialiser tous les modules (gestionnaire de données, API blockchain, moteur de trading, etc.).
4.  Démarrer les services de fond (comme la surveillance des arbitrages, si activée).
5.  Lancer l_interface utilisateur par défaut (mode `standard` simulé).

Vous devriez voir des messages de log apparaître dans la console, indiquant la progression de l_initialisation.

### 3.1. Interface Utilisateur Standard (Simulée)

L_interface utilisateur standard est actuellement simulée dans le code. Dans une version future avec une bibliothèque GUI (comme PyQt6), une fenêtre d_application s_ouvrirait. Pour l_instant, les interactions et l_affichage se font principalement via les logs.

Le `UIManager` est configuré pour démarrer en mode `standard` par défaut. Vous pouvez le vérifier dans les logs.

### 3.2. Mode VR (Simulé)

Si `enable_vr_mode = true` dans `[UISettings]` (valeur par défaut), l_application est prête à (simuler) un basculement vers le mode VR.

-   **Basculement** : La logique de basculement est gérée par `UIManager`. Dans une interface graphique réelle, un bouton permettrait de déclencher ce changement. Actuellement, ce basculement peut être testé programmatiquement si vous modifiez le code ou via des événements si l_UI était interactive.
-   **Fonctionnalité VR** : L_implémentation VR est également simulée. Elle ne lancera pas de véritable application VR mais enregistrera les actions comme si elle le faisait.

## 4. Utilisation des Fonctionnalités (via Logs et Configuration)

Étant donné que les interfaces utilisateur sont principalement simulées, l_interaction et la vérification des fonctionnalités se font via :

-   **Logs de l_Application** : Suivez les logs dans la console et dans les fichiers du répertoire `$ACP768_PROJECT_ROOT/logs/application/`. Ils indiquent les actions des modules (connexion aux nœuds, détection d_arbitrage simulée, etc.).
-   **Configuration** : Modifiez `main_config.ini` pour activer/désactiver des fonctionnalités ou changer des paramètres (ex: `start_monitoring_on_boot` dans `[ArbitrageSettings]`).
-   **Exploration du Code** : Pour comprendre le comportement détaillé, explorez les modules respectifs dans `src/acp768/`.

### 4.1. Surveillance de l_Arbitrage

Si `start_monitoring_on_boot = true` dans `[ArbitrageSettings]`, l_`ArbitrageManager` commencera à rechercher (simuler la recherche) des opportunités d_arbitrage. Vous verrez des messages de log correspondants.

### 4.2. Connexion Blockchain

L_`APIHandler` tentera de se connecter à un nœud blockchain configuré lorsque cela sera nécessaire (par exemple, lorsque l_`ArbitrageManager` démarre). Vérifiez les logs pour les messages de connexion réussie ou d_échec.

### 4.3. Prédictions ML et Analyse de Sentiment (Simulées)

Les modules `MLPredictor` et `SentimentAnalyzer` sont initialisés. Leurs fonctions de prédiction et d_analyse sont simulées et peuvent être appelées programmatiquement pour voir les logs de leur fonctionnement.

## 5. Commutabilité : Mode Simulation vs. Production

L_application a une notion de commutabilité pour faciliter les tests et une éventuelle transition vers la production.

-   **Variable d_Environnement `ACP768_APP_MODE`** :
    -   Pour un mode simulation (recommandé pour tous les tests initiaux) :
        ```bash
        export ACP768_APP_MODE=simulation
        ```
    -   Pour un mode production (À N_UTILISER QU_APRÈS DES AUDITS DE SÉCURITÉ COMPLETS ET UNE GESTION SÉCURISÉE DES CLÉS PRIVÉES) :
        ```bash
        export ACP768_APP_MODE=production
        ```
    Le `ConfigLoader` est conçu pour potentiellement charger des sections de configuration alternatives (ex: `[BlockchainNodes_simulation]`) si cette variable est définie et si de telles sections existent dans `main_config.ini`. Cette fonctionnalité avancée de chargement de sections alternatives par le `ConfigLoader` est plus conceptuelle dans la version actuelle et nécessiterait une adaptation du fichier de configuration.

-   **Impact sur la Configuration** :
    -   En mode `simulation`, assurez-vous que `main_config.ini` pointe vers des **testnets** (ex: Sepolia) et des **adresses de portefeuille de test**.
    -   En mode `production`, vous pointeriez vers le **mainnet** et utiliseriez des **adresses de portefeuille réelles** (avec une gestion de clés sécurisée externe à ce projet tel qu_il est fourni).

**Recommandation** : Pour toute utilisation, commencez en mode `simulation` avec des configurations de testnet.

## 6. Arrêt de l_Application

Pour arrêter l_application proprement, vous pouvez généralement utiliser `Ctrl+C` dans la console où elle s_exécute. Le gestionnaire de signaux intégré tentera d_arrêter tous les services de manière ordonnée (fermeture des connexions, arrêt des tâches de fond).

## 7. Dépannage

-   **Erreurs de Dépendances** : Assurez-vous que toutes les dépendances de `requirements.txt` sont correctement installées dans votre environnement virtuel.
-   **Problèmes de Configuration** : Vérifiez attentivement votre fichier `main_config.ini` pour des erreurs de syntaxe ou des valeurs incorrectes (surtout les URLs de nœuds et les ID de projet).
-   **Logs Détaillés** : Augmentez le niveau de log dans `main_config.ini` (ex: `log_level_console = DEBUG`) pour obtenir plus d_informations.
-   **Problèmes de Connexion Blockchain** :
    -   Vérifiez votre connexion Internet.
    -   Assurez-vous que votre nœud (local ou Infura) est accessible et synchronisé.
    -   Vérifiez que votre ID de projet Infura est correct et actif.

## Conclusion

Ce tutoriel vous a guidé à travers les étapes de base pour installer, configurer et lancer l_application ACP768. En raison de la nature simulée de certaines fonctionnalités avancées (UI, exécution de trades réels), une exploration plus approfondie du code et une extension des modules seront nécessaires pour une application de production complète.

N_hésitez pas à consulter le `README.md` et les commentaires dans le code pour plus de détails sur chaque module.

